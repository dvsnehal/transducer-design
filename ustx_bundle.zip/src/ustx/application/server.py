"""Local web application: a JSON API over the ``ustx`` package plus static front-end files.

Every number is computed by the package; the front end in ``static/`` only draws (DECISION D13).
Standard library only. Each ``api_*`` function maps a JSON payload to a JSON-able result, so the
tests call them directly.

Run:  python -m ustx.application.server        (opens http://localhost:8050)
"""

from __future__ import annotations

import json
import math
import sys
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np
import pandas as pd

from ustx import EPS0, __version__
from ustx.acoustics import Layer, layer_from_material, quarter_wave_thickness
from ustx.materials import default_database
from ustx.models import Electrical, TransducerDesign, make_grid, simulate
from ustx.optimisation import (
    APPLICATIONS,
    Application,
    DesignSpace,
    ParetoProblem,
    run_nsga2,
    select_recommended,
)
from ustx.performance import evaluate, impulse_response, unloaded_resonances
from ustx.reporting import DISCLAIMER, design_json, figure_set, metrics_table, pdf_report, png_bytes, response_table
from ustx.robustness import ToleranceSpec, monte_carlo, sobol_indices, summarise, yield_fraction

ROOT = Path(__file__).resolve().parents[3]
RESULTS = ROOT / "results"
STATIC = Path(__file__).parent / "static"
FILES = {  # whitelist: nothing else on disk is served
    "/": (STATIC / "index.html", "text/html; charset=utf-8"),
    "/app.css": (STATIC / "app.css", "text/css; charset=utf-8"),
    "/app.js": (STATIC / "app.js", "text/javascript; charset=utf-8"),
}
_DB = None


def _plotly_js() -> Path:
    import plotly  # only the desktop server needs it; the browser build ships plotly.min.js itself

    return Path(plotly.__file__).parent / "package_data" / "plotly.min.js"


def db():
    global _DB
    if _DB is None:
        _DB = default_database()
    return _DB


def jsonable(o):
    """Plain JSON types only; NaN and infinity become null (browsers reject them)."""
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, np.generic):
        o = o.item()
    if isinstance(o, float) and not math.isfinite(o):
        return None
    return o


def records(df: pd.DataFrame) -> list[dict]:
    return json.loads(df.to_json(orient="records"))


def csv_records(path: Path) -> list[dict]:
    return records(pd.read_csv(path)) if path.exists() else []


# --------------------------------------------------------------------------- design state
def app_for(f_target: float) -> Application:
    for a in APPLICATIONS.values():
        if abs(a.f_target - f_target) < 1:
            return a
    return Application("custom", "Custom", f_target)


def default_state() -> dict:
    return {
        "f_target": 7.5e6,
        "piezo": "PZT5A_TP226",
        "s": 1.0,
        "layers": [
            {"kind": "ideal", "material": "SIC_EPOXY", "z": 8.99e6, "q": 1.0},
            {"kind": "ideal", "material": "PARYLENE_C", "z": 2.39e6, "q": 1.0},
        ],
        "backing": "W_EPOXY_110",
        "backing_custom": None,
        "load_z": 1.54e6,
        "rs": 50.0,
        "rl": 50.0,
        "tuning": "none",
        "kappa": 1.0,
    }


def build_design(s: dict) -> TransducerDesign:
    d = db()
    pz = d.piezo[s["piezo"]]
    ft = float(s["f_target"])
    if not 0.1e6 <= ft <= 100e6:
        raise ValueError("Target frequency must lie between 0.1 and 100 MHz.")
    if len(s["layers"]) > 3:
        raise ValueError("At most three matching layers are supported.")
    app = app_for(ft)
    thickness = s["s"] * pz.velocity / (2 * ft)
    layers = []
    for L in s["layers"]:
        if L["kind"] == "database":
            layers.append(layer_from_material(d.passive[L["material"]], frequency=ft, quarter_waves=L["q"]))
        else:
            layers.append(Layer("Ideal, free impedance", L["z"], 2500.0, L["q"] * quarter_wave_thickness(2500.0, ft)))
    bz = s["backing_custom"] if s["backing_custom"] is not None else d.passive[s["backing"]].z_specific
    el = Electrical(s["rs"], s["rl"])
    if s["tuning"] != "none":
        c0 = pz.eps33s_rel * EPS0 * app.area / thickness
        el = Electrical(s["rs"], s["rl"], s["tuning"], s["kappa"] / ((2 * math.pi * ft) ** 2 * c0))
    return TransducerDesign(
        pz, thickness, app.area, tuple(layers), bz, load_z=s["load_z"], electrical=el, name="designer"
    )


def state_from_space(space: DesignSpace, x: np.ndarray) -> dict:
    c = space.decode(x)
    return {
        "f_target": space.app.f_target,
        "piezo": c["piezo"],
        "s": c["s"],
        "layers": [
            {"kind": "database", "material": m, "z": space.db.passive[m].z_specific, "q": q}
            for m, q in zip(c["matching"], c["q"])
        ],
        "backing": c["backing"],
        "backing_custom": None,
        "load_z": space.app.tissue_z,
        "rs": space.source_resistance,
        "rl": space.receiver_resistance,
        "tuning": c["tuning"],
        "kappa": c["kappa"],
    }


def designs(space: DesignSpace, X, F) -> list[dict]:
    return [
        {
            "label": space.label(space.decode(x)),
            "fbw": -f[0],
            "il": f[1],
            "tau": f[2],
            "state": state_from_space(space, x),
        }
        for x, f in zip(X, F)
    ]


def db_norm(h: np.ndarray) -> np.ndarray:
    a = np.abs(h)
    with np.errstate(divide="ignore"):
        return np.maximum(20 * np.log10(a / a.max()), -120.0)


# --------------------------------------------------------------------------- API
def api_meta(_=None) -> dict:
    d = db()
    missing, derived = d.missing_report()
    exp = RESULTS / "experiments"
    experiments = []
    for p in sorted(exp.glob("*.json")) if exp.exists() else []:
        j = json.loads(p.read_text())
        experiments.append({"Experiment": j["id"], "Title": j["title"], "Runtime (s)": j.get("runtime_s")})
    passive = lambda role: [  # noqa: E731
        {"id": m.material_id, "name": m.name, "z": m.z_specific} for m in d.by_role(role)
    ]
    return {
        "version": __version__,
        "disclaimer": DISCLAIMER,
        "default_state": default_state(),
        "applications": {k: {"name": a.name, "f_target": a.f_target} for k, a in APPLICATIONS.items()},
        "piezo": [
            {
                "id": k,
                "name": m.name,
                "Z (MRayl)": m.z_specific / 1e6,
                "Velocity (m/s)": m.velocity,
                "kt": m.kt,
                "εS33/ε0": m.eps33s_rel,
                "Qm": m.qm,
                "tan δ": m.tan_delta_e,
                "flags": list(m.flags),
            }
            for k, m in d.piezo.items()
        ],
        "matching": passive("matching"),
        "backing": passive("backing"),
        "table": records(d.table()),
        "excluded": d.excluded,
        "missing": records(missing[["material_id", "property", "status", "notes"]]),
        "derived": records(derived),
        "sources": list(d.sources.values()),
        "counts": {
            "piezo": len(d.piezo),
            "passive": len(d.passive),
            "excluded": len(d.excluded),
            "derived": len(d.derivations),
        },
        "experiments": experiments,
        "recommended": csv_records(RESULTS / "tables" / "exp11_recommended_designs.csv"),
        "transfer": csv_records(RESULTS / "tables" / "exp11_transfer_matrix.csv"),
        "robust_vs_nominal": csv_records(RESULTS / "tables" / "exp14_robust_vs_nominal.csv"),
        "fronts": [p.stem.replace("front_", "") for p in sorted((RESULTS / "optimisation").glob("front_*_*.npz"))],
    }


def api_simulate(s: dict) -> dict:
    d = build_design(s)
    ft = s["f_target"]
    g = make_grid(ft)
    r = simulate(d, g)
    m = evaluate(d, ft, g, response=r)
    t, sig = impulse_response(r.f, r.h_pe)
    win = (t * ft > -8) & (t * ft < 24)  # the pulse, in cycles of the target frequency
    ur = unloaded_resonances(d.piezo, d.thickness, d.area)
    app = app_for(ft)
    backing_name = "Custom impedance" if s["backing_custom"] is not None else db().passive[s["backing"]].name
    block = lambda role, name, z, t_=None: {"role": role, "name": name, "z": z, "t": t_}  # noqa: E731
    stack = [
        block("backing", backing_name, d.backing_z),
        *(block("rear", L.name, L.z_specific, L.thickness) for L in reversed(d.rear_layers)),
        block("piezo", d.piezo.name, d.piezo.z_specific, d.thickness),
        *(block("matching", L.name, L.z_specific, L.thickness) for L in d.front_layers),
        block("load", "Tissue", d.load_z),
    ]
    return {
        "valid": bool(m.valid),
        "piezo_name": d.piezo.name,
        "flags": list(d.piezo.flags),
        "thickness_um": d.thickness * 1e6,
        "aperture_mm": app.aperture_diameter * 1e3,
        "area_mm2": app.area * 1e6,
        "headline": {
            "fc": m.fc_mhz,
            "fbw": m.fbw6_pe_pct,
            "il": m.il2_db_at_fc,
            "tau": m.tau20_us,
            "zin": m.zin_abs_ohm_at_fc,
        },
        "stack": stack,
        "source_ohm": s["rs"],
        "f": r.f / 1e6,
        "pe": db_norm(r.h_pe),
        "tx": db_norm(r.h_tx),
        "rx": db_norm(r.h_rx),
        "t": t[win] * 1e6,
        "pulse": sig[win] / np.abs(sig).max(),
        "resonances": [
            {"Quantity": "Series resonance fs (unloaded, lossless)", "MHz": ur.fs_lossless / 1e6},
            {"Quantity": "Parallel resonance fp = v/2t (unloaded)", "MHz": ur.fp_lossless / 1e6},
            {"Quantity": "Maximum conductance (unloaded, lossy)", "MHz": ur.f_max_conductance / 1e6},
            {"Quantity": "Loaded resonance (min |Z|)", "MHz": m.f_min_abs_z_mhz},
            {"Quantity": "Loaded anti-resonance (max |Z|)", "MHz": m.f_max_abs_z_mhz},
            {"Quantity": "Pulse-echo centre frequency", "MHz": m.fc_mhz},
        ],
        "metrics": records(metrics_table(m)),
    }


def api_optimise(p: dict) -> dict:
    """NSGA-II Pareto search for one application."""
    pop, gens, seed = int(p["pop"]), int(p["gens"]), int(p["seed"])
    if not (8 <= pop <= 400 and 2 <= gens <= 500):
        raise ValueError("Population must be 8 to 400 and generations 2 to 500.")
    base = APPLICATIONS[p["app"]]
    app = Application(
        base.key, base.name, base.f_target, fc_tolerance=float(p["tol"]) / 100, ripple_max_db=float(p["ripple"])
    )
    space = DesignSpace(app, piezo_ids=tuple(p["piezos"])) if p.get("piezos") else DesignSpace(app)
    r = run_nsga2(ParetoProblem(space), pop, gens, seed, app.f_target)
    return {
        "kind": "pareto",
        "app": p["app"],
        "evals": r.history_evals,
        "history": r.history_hv,
        "designs": designs(space, r.x_best, r.f_best),
        "feasible": len(r.x_best) > 0,
    }


def api_front(p: dict) -> dict:
    name = p["name"]
    if name not in api_meta()["fronts"]:
        raise ValueError(f"No stored front named {name!r}.")
    data = np.load(RESULTS / "optimisation" / f"front_{name}.npz")
    return {"designs": designs(DesignSpace(APPLICATIONS[name.split("_")[0]]), data["X"], data["F"])}


def api_select(p: dict) -> dict:
    """Index of the recommended design. F rows are (FBW %, IL dB, tau us) as shown to the user."""
    F = np.array(p["F"], dtype=float)
    F[:, 0] *= -1
    return {"k": int(select_recommended(F, float(p["margin"])))}


def _spec(p: dict) -> ToleranceSpec:
    spec = ToleranceSpec(**{k: float(v) for k, v in p["spec"].items()})
    return spec if p.get("vary_load", True) else spec.without_load()


MC_KEYS = ("fc_mhz", "fbw6_pe_pct", "il2_db_at_fc")


def api_montecarlo(p: dict) -> dict:
    n = int(p["n"])
    if not 10 <= n <= 5000:
        raise ValueError("Monte Carlo samples must be 10 to 5000.")
    s = p["state"]
    d = build_design(s)
    ft = s["f_target"]
    nom = evaluate(d, ft, make_grid(ft)).as_dict()
    df = monte_carlo(d, ft, n=n, seed=int(p["seed"]), spec=_spec(p))
    tol = app_for(ft).fc_tolerance
    return {
        "n": len(df),
        "tolerance_pct": 100 * tol,
        "yield_pct": 100 * yield_fraction(df, ft, tol),
        "nominal": {k: nom[k] for k in MC_KEYS},
        "samples": {k: df[k].to_numpy() for k in MC_KEYS},
        "summary": [x.__dict__ for x in summarise(df, nom)],
    }


def api_sobol(p: dict) -> dict:
    s = p["state"]
    return {"rows": records(sobol_indices(build_design(s), s["f_target"], n_base=128, spec=_spec(p)))}


def api_applications(_=None) -> dict:
    out = []
    for key, app in APPLICATIONS.items():
        f = RESULTS / "optimisation" / f"design_{key}_nominal.json"
        if not f.exists():
            continue
        x = np.array(json.loads(f.read_text())["x"])
        space = DesignSpace(app)
        r = simulate(space.to_design(x), make_grid(app.f_target))
        out.append(
            {
                "key": key,
                "name": app.name,
                "x": r.f / app.f_target,
                "y": db_norm(r.h_pe),
                "state": state_from_space(space, x),
            }
        )
    return {"designs": out}


def api_export(p: dict) -> tuple[bytes, str, str]:
    s, kind = p["state"], p["kind"]
    d = build_design(s)
    g = make_grid(s["f_target"])
    r = simulate(d, g)
    m = evaluate(d, s["f_target"], g, response=r)
    if kind == "metrics":
        return metrics_table(m).to_csv(index=False).encode(), "text/csv", "metrics.csv"
    if kind == "response":
        return response_table(r).to_csv(index=False).encode(), "text/csv", "response.csv"
    if kind == "design":
        return design_json(d).encode(), "application/json", "design.json"
    if kind == "pdf":
        return pdf_report(d, m, r), "application/pdf", "transducer_report.pdf"
    figs = figure_set(r)
    if kind.startswith("fig:") and kind[4:] in figs:
        return png_bytes(figs[kind[4:]]), "image/png", f"{kind[4:]}.png"
    raise ValueError(f"Unknown export kind {kind!r}.")


GET = {"/api/meta": api_meta, "/api/applications": api_applications}
POST = {
    "/api/simulate": api_simulate,
    "/api/optimise": api_optimise,
    "/api/front": api_front,
    "/api/select": api_select,
    "/api/montecarlo": api_montecarlo,
    "/api/sobol": api_sobol,
    "/api/export": api_export,
}


def call(fn, payload) -> tuple[int, bytes, str, str]:
    """Run one API function: (status, body, media type, download file name)."""
    try:
        out = fn(payload)
    except (KeyError, ValueError, TypeError, IndexError) as e:  # bad input from the client
        msg = f"Unknown name: {e}" if isinstance(e, KeyError) else str(e)
        return 400, json.dumps({"error": msg}).encode(), "application/json", ""
    if isinstance(out, tuple):
        return (200, *out)
    return 200, json.dumps(jsonable(out), allow_nan=False).encode(), "application/json", ""


def handle(path: str, payload_json: str | None) -> tuple[int, bytes, str, str]:
    """Entry point for the browser build (Pyodide), which has no HTTP server."""
    if payload_json is None:
        return call(GET[path], None) if path in GET else (404, b"Not found", "text/plain", "")
    if path not in POST:
        return 404, b"Not found", "text/plain", ""
    try:
        payload = json.loads(payload_json)
    except json.JSONDecodeError:
        return 400, b'{"error": "Request body is not valid JSON."}', "application/json", ""
    return call(POST[path], payload)


class Handler(BaseHTTPRequestHandler):
    def _send(self, code: int, body: bytes, mime: str, filename: str = "") -> None:
        self.send_response(code)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = self.path.split("?")[0]
        if path in FILES:
            f, mime = FILES[path]
            return self._send(200, f.read_bytes(), mime)
        if path == "/plotly.min.js":
            return self._send(200, _plotly_js().read_bytes(), "text/javascript")
        if path in GET:
            return self._send(*call(GET[path], None))
        self._send(404, b"Not found", "text/plain")

    def do_POST(self) -> None:
        if self.path not in POST:
            return self._send(404, b"Not found", "text/plain")
        n = int(self.headers.get("Content-Length") or 0)
        if n > 5_000_000:
            return self._send(413, b"Payload too large", "text/plain")
        try:
            payload = json.loads(self.rfile.read(n))
        except json.JSONDecodeError:
            return self._send(400, b'{"error": "Request body is not valid JSON."}', "application/json")
        self._send(*call(POST[self.path], payload))

    def log_message(self, *_) -> None:  # keep the terminal quiet
        pass


def serve(port: int = 8050) -> ThreadingHTTPServer:
    # shortcut: local single-user server bound to loopback, no auth; put a real server in front before sharing it
    return ThreadingHTTPServer(("127.0.0.1", port), Handler)


def main() -> None:
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8050
    httpd = serve(port)
    url = f"http://localhost:{port}"
    print(f"ustx {__version__} application at {url}  (Ctrl+C to stop)")
    if "--no-browser" not in sys.argv:
        webbrowser.open(url)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
