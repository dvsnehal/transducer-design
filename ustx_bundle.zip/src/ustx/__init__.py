"""ustx: one-dimensional modelling and optimisation of piezoelectric ultrasound transducers.

Sub-packages
------------
materials      traceable material database, derivation rules and validation
acoustics      passive transmission-line layers (framework section 4)
models         three-port, Mason, KLM, BVD and the full transducer two-port (sections 2, 3, 5)
performance    resonances, transfer-function metrics and time-domain metrics (sections 6, 7)
optimisation   design space, objective definitions and optimiser runners (section 8)
robustness     tolerance models, Monte Carlo, local and global sensitivity
visualisation  figure functions shared by experiments and the application

Equation numbers in docstrings refer to ``docs/02_Mathematical_Framework.md``.
"""

from __future__ import annotations

import logging

__version__ = "1.0.0"

logging.getLogger(__name__).addHandler(logging.NullHandler())

EPS0 = 8.8541878128e-12
"""Vacuum permittivity, F/m (CODATA 2018)."""
