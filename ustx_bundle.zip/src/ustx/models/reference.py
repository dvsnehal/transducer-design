"""Independent reference models used to cross-check the KLM cascade (DECISION D02).

* ``zin_threeport``  numerical solution of the 3x3 three-port (Eq. 2.2)
* ``zin_closed_form`` closed-form loaded impedance (Eq. 2.9)
* ``zin_mason``      Mason circuit (Eq. 3.1)
* ``zin_klm``        KLM circuit written directly (Eq. 3.4)
* ``zin_unloaded``   free plate (Eq. 2.10)

Loads ``z_back`` and ``z_front`` are *mechanical* impedances (N s/m) seen by the plate faces.
"""

from __future__ import annotations

import math

import numpy as np

from ustx.models.piezo import PlateConstants, coupling_squared


def _prep(pc: PlateConstants, f, z_back, z_front):
    f = np.atleast_1d(np.asarray(f, dtype=float))
    zb = np.broadcast_to(np.asarray(z_back, dtype=complex), f.shape)
    zf = np.broadcast_to(np.asarray(z_front, dtype=complex), f.shape)
    return f, 2 * math.pi * f, pc.theta(f), zb, zf


def threeport_solve(pc: PlateConstants, f, z_back, z_front):
    """Solve Eq. 2.2 with F = -Z v at both faces for V = 1 V.

    Returns (Zin, v1, v2) with face velocities positive into the plate.
    """
    f, w, theta, zb, zf = _prep(pc, f, z_back, z_front)
    z11 = pc.z0 / (1j * np.tan(theta))
    z12 = pc.z0 / (1j * np.sin(theta))
    hw = pc.h33 / (1j * w)
    m = np.empty(f.shape + (3, 3), dtype=complex)
    m[:, 0, 0] = z11 + zb
    m[:, 0, 1] = z12
    m[:, 0, 2] = hw
    m[:, 1, 0] = z12
    m[:, 1, 1] = z11 + zf
    m[:, 1, 2] = hw
    m[:, 2, 0] = hw
    m[:, 2, 1] = hw
    m[:, 2, 2] = 1.0 / (1j * w * pc.c0)
    rhs = np.zeros(f.shape + (3, 1), dtype=complex)
    rhs[:, 2, 0] = 1.0
    x = np.linalg.solve(m, rhs)[..., 0]
    return 1.0 / x[:, 2], x[:, 0], x[:, 1]


def zin_threeport(pc: PlateConstants, f, z_back, z_front) -> np.ndarray:
    return threeport_solve(pc, f, z_back, z_front)[0]


def zin_closed_form(pc: PlateConstants, f, z_back, z_front) -> np.ndarray:
    """Eq. 2.9."""
    f, w, theta, zb, zf = _prep(pc, f, z_back, z_front)
    z1, z2 = zb / pc.z0, zf / pc.z0
    num = 1j * (z1 + z2) * np.sin(theta) - 2.0 * (1.0 - np.cos(theta))
    den = (1.0 + z1 * z2) * np.sin(theta) - 1j * (z1 + z2) * np.cos(theta)
    return (1.0 / (1j * w * pc.c0)) * (1.0 + (coupling_squared(pc) / theta) * num / den)


def zin_unloaded(pc: PlateConstants, f) -> np.ndarray:
    """Eq. 2.10, free plate (air on both faces)."""
    f = np.atleast_1d(np.asarray(f, dtype=float))
    w = 2 * math.pi * f
    half = pc.theta(f) / 2
    return (1.0 / (1j * w * pc.c0)) * (1.0 - coupling_squared(pc) * np.tan(half) / half)


def zin_mason(pc: PlateConstants, f, z_back, z_front) -> np.ndarray:
    """Eq. 3.1."""
    f, w, theta, zb, zf = _prep(pc, f, z_back, z_front)
    n = pc.h33 * pc.c0
    z_arm = 1j * pc.z0 * np.tan(theta / 2.0)
    z_shunt = pc.z0 / (1j * np.sin(theta))
    a, b = z_arm + zb, z_arm + zf
    z_ac = z_shunt + a * b / (a + b)
    zc0 = 1.0 / (1j * w * pc.c0)
    z_branch = -zc0 + z_ac / n**2
    return zc0 * z_branch / (zc0 + z_branch)


def zin_klm(pc: PlateConstants, f, z_back, z_front) -> np.ndarray:
    """Eq. 3.4, written independently of the cascade in ``transducer.py``."""
    f, w, theta, zb, zf = _prep(pc, f, z_back, z_front)
    half = theta / 2
    m_par = pc.h33 / (w * pc.z0)
    jx1 = 1j * pc.z0 * m_par**2 * np.sin(theta)
    phi = 1.0 / (2.0 * m_par * np.sin(half))
    t = np.tan(half)
    z_left = pc.z0 * (zb + 1j * pc.z0 * t) / (pc.z0 + 1j * zb * t)
    z_right = pc.z0 * (zf + 1j * pc.z0 * t) / (pc.z0 + 1j * zf * t)
    z_centre = z_left * z_right / (z_left + z_right)
    return 1.0 / (1j * w * pc.c0) + jx1 + z_centre / phi**2
