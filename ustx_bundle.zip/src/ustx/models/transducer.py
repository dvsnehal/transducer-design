"""Complete transducer: KLM cascade as an electrical-to-acoustic two-port (framework section 5).

The two-port relates (V, I) at the electrical terminals to (F, u) at the outer front face, with u
out of the transducer into the load. It is computed as the product (Eq. 5.1)

    T = T_tuning . T_series(1/(jwC0) + jX1) . T_phi . T_shunt(1/Z_left) . T_half . T_layer1 ... T_layerN

Every factor has unit determinant, so det T = 1 (tested).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace

import numpy as np

from ustx.acoustics.layers import Layer, abcd_layer, stack_input_impedance
from ustx.materials.database import PiezoMaterial
from ustx.models.piezo import PlateConstants, plate_constants

TUNING_OPTIONS = ("none", "series_L", "shunt_L")


@dataclass(frozen=True)
class Electrical:
    """Electrical terminations and optional tuning inductor (part of the probe).

    source_resistance: pulser output resistance R_s (ohm).
    receiver_resistance: receiver input resistance R_L (ohm).
    tuning: 'none', 'series_L' or 'shunt_L'.
    inductance: tuning inductance (H); ignored when tuning == 'none'.
    """

    source_resistance: float = 50.0
    receiver_resistance: float = 50.0
    tuning: str = "none"
    inductance: float = 0.0

    def __post_init__(self) -> None:
        if self.tuning not in TUNING_OPTIONS:
            raise ValueError(f"tuning must be one of {TUNING_OPTIONS}")
        if self.source_resistance <= 0 or self.receiver_resistance <= 0:
            raise ValueError("terminations must be positive")
        if self.tuning != "none" and self.inductance <= 0:
            raise ValueError("a tuning inductor needs a positive inductance")


@dataclass(frozen=True)
class TransducerDesign:
    """A complete 1-D transducer configuration.

    front_layers are ordered from the piezoelectric face outwards to the load.
    rear_layers are ordered from the piezoelectric rear face outwards to the backing half-space.
    backing_z and load_z are specific impedances (Rayl) of semi-infinite media.
    """

    piezo: PiezoMaterial
    thickness: float
    area: float
    front_layers: tuple[Layer, ...] = ()
    backing_z: float = 0.0
    rear_layers: tuple[Layer, ...] = ()
    load_z: float = 1.54e6
    electrical: Electrical = field(default_factory=Electrical)
    name: str = ""

    def __post_init__(self) -> None:
        if self.thickness <= 0 or self.area <= 0:
            raise ValueError("thickness and area must be positive")
        if self.backing_z < 0 or self.load_z <= 0:
            raise ValueError("backing impedance must be >= 0 and load impedance > 0")

    def with_(self, **changes) -> TransducerDesign:
        return replace(self, **changes)

    def describe(self) -> dict:
        """Plain-data description for tables and exports."""
        return {
            "name": self.name,
            "piezo": self.piezo.material_id,
            "thickness_um": self.thickness * 1e6,
            "area_mm2": self.area * 1e6,
            "front_layers": "; ".join(
                f"{L.name} {L.z_specific / 1e6:.2f} MRayl {L.thickness * 1e6:.1f} um" for L in self.front_layers
            ) or "none",
            "rear_layers": "; ".join(f"{L.name} {L.thickness * 1e6:.1f} um" for L in self.rear_layers) or "none",
            "backing_MRayl": self.backing_z / 1e6,
            "load_MRayl": self.load_z / 1e6,
            "R_s_ohm": self.electrical.source_resistance,
            "R_L_ohm": self.electrical.receiver_resistance,
            "tuning": self.electrical.tuning,
            "L_uH": self.electrical.inductance * 1e6,
        }


@dataclass
class Response:
    """Frequency-domain response of a design (all arrays over ``f``)."""

    f: np.ndarray
    zin: np.ndarray  # electrical input impedance with acoustic loads, ohm
    t11: np.ndarray
    t12: np.ndarray
    t21: np.ndarray
    t22: np.ndarray
    h_tx: np.ndarray  # Pa/V, front pressure per volt of source EMF (Eq. 5.3)
    h_rx: np.ndarray  # V/Pa, receiver voltage per incident pressure (Eq. 5.4)
    h_pe: np.ndarray  # V/V, pulse-echo for an ideal planar reflector (Eq. 5.5)
    g_tx: np.ndarray  # one-way transmit transducer power gain
    g_rx: np.ndarray  # one-way receive transducer power gain
    efficiency: np.ndarray  # acoustic power to load / electrical power accepted
    power_back_fraction: np.ndarray  # fraction of radiated acoustic power entering the rear stack
    design: TransducerDesign

    @property
    def det(self) -> np.ndarray:
        return self.t11 * self.t22 - self.t12 * self.t21

    def insertion_loss_db(self) -> np.ndarray:
        """Two-way insertion loss (Eq. 5.6), dB, positive = loss."""
        rs = self.design.electrical.source_resistance
        rl = self.design.electrical.receiver_resistance
        with np.errstate(divide="ignore"):
            return -10.0 * np.log10(4.0 * (rs / rl) * np.abs(self.h_pe) ** 2)


def _mul(a, b):
    """Product of two 2x2 matrices stored as 4-tuples of arrays."""
    a11, a12, a21, a22 = a
    b11, b12, b21, b22 = b
    return (a11 * b11 + a12 * b21, a11 * b12 + a12 * b22,
            a21 * b11 + a22 * b21, a21 * b12 + a22 * b22)


def rear_impedance(design: TransducerDesign, f: np.ndarray) -> np.ndarray:
    """Mechanical impedance seen by the plate rear face (Z1)."""
    return stack_input_impedance(design.rear_layers, f, design.area, design.backing_z * design.area)


def front_impedance(design: TransducerDesign, f: np.ndarray) -> np.ndarray:
    """Mechanical impedance seen by the plate front face (Z2)."""
    return stack_input_impedance(design.front_layers, f, design.area, design.load_z * design.area)


def two_port(design: TransducerDesign, f: np.ndarray, pc: PlateConstants | None = None):
    """Return (T11, T12, T21, T22, Z_left, pc) of Eq. 5.1."""
    f = np.asarray(f, dtype=float)
    if np.any(f <= 0):
        raise ValueError("frequencies must be positive (f = 0 is handled analytically)")
    pc = pc or plate_constants(design.piezo, design.thickness, design.area)
    w = 2 * math.pi * f
    theta = pc.theta(f)
    half = theta / 2
    ch, sh = np.cos(half), np.sin(half)
    z0 = pc.z0

    z1 = rear_impedance(design, f)
    z_left = z0 * (z1 * ch + 1j * z0 * sh) / (z0 * ch + 1j * z1 * sh)

    m_par = pc.h33 / (w * z0)
    z_series = 1.0 / (1j * w * pc.c0) + 1j * z0 * m_par**2 * np.sin(theta)
    phi = 1.0 / (2.0 * m_par * sh)
    one = np.ones_like(w, dtype=complex)
    zero = np.zeros_like(w, dtype=complex)

    t = (one, z_series, zero, one)
    el = design.electrical
    if el.tuning == "series_L":
        t = _mul((one, 1j * w * el.inductance, zero, one), t)
    elif el.tuning == "shunt_L":
        t = _mul((one, zero, 1.0 / (1j * w * el.inductance), one), t)
    t = _mul(t, (1.0 / phi, zero, zero, phi))
    t = _mul(t, (one, zero, 1.0 / z_left, one))
    t = _mul(t, (ch, 1j * z0 * sh, 1j * sh / z0, ch))
    for layer in design.front_layers:
        t = _mul(t, abcd_layer(layer, f, design.area))
    return (*t, z_left, pc)


def simulate(design: TransducerDesign, f: np.ndarray) -> Response:
    """Evaluate all frequency-domain quantities of framework section 5."""
    f = np.asarray(f, dtype=float)
    t11, t12, t21, t22, z_left, pc = two_port(design, f)
    a = design.area
    zt = design.load_z * a
    el = design.electrical
    rs, rl = el.source_resistance, el.receiver_resistance

    num_v = t11 * zt + t12
    num_i = t21 * zt + t22
    zin = num_v / num_i
    d_s = num_v + rs * num_i
    d_l = num_v + rl * num_i
    h_tx = design.load_z / d_s
    h_rx = 2.0 * a * rl / d_l
    h_pe = h_tx * h_rx
    g_tx = 4.0 * rs * zt / np.abs(d_s) ** 2
    g_rx = np.abs(h_rx) ** 2 * design.load_z / (a * rl)

    # power bookkeeping at the centre tap for the forward/backward split
    i_in = 1.0 / d_s  # current for unit source EMF
    p_elec = 0.5 * np.real(zin) * np.abs(i_in) ** 2
    u_out = i_in / num_i  # velocity into the load for unit EMF: I = (T21 Zt + T22) u
    p_front = 0.5 * zt * np.abs(u_out) ** 2
    with np.errstate(divide="ignore", invalid="ignore"):
        efficiency = np.where(p_elec > 0, p_front / p_elec, 0.0)
    back = backward_fraction(design, f, z_left, pc)
    return Response(f, zin, t11, t12, t21, t22, h_tx, h_rx, h_pe, g_tx, g_rx, efficiency, back, design)


def backward_fraction(design: TransducerDesign, f: np.ndarray, z_left: np.ndarray,
                      pc: PlateConstants) -> np.ndarray:
    """Fraction of the power delivered to the centre tap that flows towards the backing.

    The centre-tap force drives Z_left (rear half of the plate + rear stack) and Z_right
    (front half + front stack + load) in parallel, so the power into each branch is
    proportional to Re(1/Z). Losses inside each half of the plate count towards that half.
    """
    half = pc.theta(f) / 2
    ch, sh = np.cos(half), np.sin(half)
    z2 = front_impedance(design, f)
    z_right = pc.z0 * (z2 * ch + 1j * pc.z0 * sh) / (pc.z0 * ch + 1j * z2 * sh)
    p_left = np.real(1.0 / z_left)
    p_right = np.real(1.0 / z_right)
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(p_left + p_right > 0, p_left / (p_left + p_right), 0.0)


def make_grid(f_target: float, n: int = 2048, fmax_factor: float = 4.0) -> np.ndarray:
    """Uniform grid f_k = k df, k = 1..n, with f_max = fmax_factor * f_target (framework section 7)."""
    if n < 64:
        raise ValueError("grid too coarse")
    fmax = fmax_factor * f_target
    return np.arange(1, n + 1) * (fmax / n)
