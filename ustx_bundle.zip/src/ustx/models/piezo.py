"""Thickness-mode piezoelectric plate constants (framework sections 1-2)."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ustx import EPS0
from ustx.materials.database import PiezoMaterial


@dataclass(frozen=True)
class PlateConstants:
    """Complex constants of a plate, independent of frequency except through ``theta``."""

    c33d: complex  # Pa, c'(1 + j/Qm)
    eps33s: complex  # F/m, eps'(1 - j tan d)
    h33: complex  # V/m, kt sqrt(c/eps)
    velocity: complex  # m/s, sqrt(c/rho)
    z0: complex  # mechanical impedance rho v A, N s/m
    c0: complex  # clamped capacitance eps A / t, F
    thickness: float
    area: float
    density: float

    def theta(self, f: np.ndarray | float) -> np.ndarray:
        """Total electrical length omega t / v (complex when lossy)."""
        return 2 * math.pi * np.asarray(f, dtype=float) * self.thickness / self.velocity


def plate_constants(material: PiezoMaterial, thickness: float, area: float) -> PlateConstants:
    """Complex plate constants with mechanical and dielectric loss (DECISION D05).

    Piezoelectric loss is neglected (kt real, ASSUMPTIONS A7).
    """
    if thickness <= 0 or area <= 0:
        raise ValueError("thickness and area must be positive")
    mech = 0.0 if math.isinf(material.qm) else 1.0 / material.qm
    c33d = material.c33d * (1 + 1j * mech)
    eps = material.eps33s_rel * EPS0 * (1 - 1j * material.tan_delta_e)
    h33 = material.kt * np.sqrt(c33d / eps)
    vel = np.sqrt(c33d / material.density)
    z0 = material.density * vel * area
    c0 = eps * area / thickness
    return PlateConstants(complex(c33d), complex(eps), complex(h33), complex(vel), complex(z0),
                          complex(c0), thickness, area, material.density)


def coupling_squared(pc: PlateConstants) -> complex:
    """kt^2 = h^2 eps / c  (Eq. 1.6), complex when losses are present."""
    return pc.h33**2 * pc.eps33s / pc.c33d
