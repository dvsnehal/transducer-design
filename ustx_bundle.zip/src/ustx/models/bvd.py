"""Butterworth-Van Dyke (BVD) lumped approximation of the free plate (framework section 3.3).

Derivation used here (documented in docs/02_Mathematical_Framework.md, section 3.3):
the four elements C0', R1, L1, C1 are chosen so that the lossless BVD circuit reproduces three
exact properties of the free plate (Eq. 2.10):

1. the low-frequency capacitance C_LF = C0 / (1 - kt^2),
2. the series resonance fs and 3. the parallel resonance fp, with fs/fp from Eq. 2.12.

For a BVD circuit, C0' + C1 = C_LF and (fp/fs)^2 = 1 + C1/C0'. Hence

    C0' = C_LF (fs/fp)^2,  C1 = C_LF (1 - (fs/fp)^2),  L1 = 1 / ((2 pi fs)^2 C1),
    R1 = 2 pi fs L1 / Qm   (zero when Qm is infinite).

The BVD model is valid near the fundamental only. It is used for diagnostics, never for
bandwidth or pulse predictions.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ustx.materials.database import PiezoMaterial, series_parallel_ratio
from ustx.models.piezo import plate_constants


@dataclass(frozen=True)
class BVDParameters:
    c0p: float
    r1: float
    l1: float
    c1: float
    fs: float
    fp: float


def bvd_from_material(material: PiezoMaterial, thickness: float, area: float) -> BVDParameters:
    pc = plate_constants(material.with_overrides(qm=math.inf, tan_delta_e=0.0), thickness, area)
    c_lf = pc.c0.real / (1 - material.kt**2)
    r = series_parallel_ratio(material.kt)
    fp = material.velocity / (2 * thickness)
    fs = r * fp
    c0p = c_lf * r**2
    c1 = c_lf * (1 - r**2)
    l1 = 1.0 / ((2 * math.pi * fs) ** 2 * c1)
    r1 = 0.0 if math.isinf(material.qm) else 2 * math.pi * fs * l1 / material.qm
    return BVDParameters(c0p, r1, l1, c1, fs, fp)


def zin_bvd(params: BVDParameters, f) -> np.ndarray:
    w = 2 * math.pi * np.atleast_1d(np.asarray(f, dtype=float))
    z_motional = params.r1 + 1j * w * params.l1 + 1.0 / (1j * w * params.c1)
    # Z_m / (1 + j w C0' Z_m) stays finite at the lossless series resonance where Z_m = 0.
    return z_motional / (1.0 + 1j * w * params.c0p * z_motional)
