"""Optimiser runners with seeded, logged, reproducible runs (pymoo, DECISION D14).

All runs use pymoo's default operators for the chosen algorithm, so that the GA/PSO comparison
is between published default configurations rather than between hand-tuned variants:

* GA      pymoo GA: tournament selection, SBX crossover, polynomial mutation, (mu + lambda) survival
* PSO     pymoo PSO: inertia w = 0.9, c1 = c2 = 2.0, adaptive parameter control (pymoo default)
* NSGA-II pymoo NSGA2: non-dominated sorting with crowding distance (Deb et al. 2002)

Constraints are handled by pymoo's feasibility-first rule in all three.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

import numpy as np
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.algorithms.soo.nonconvex.ga import GA
from pymoo.algorithms.soo.nonconvex.pso import PSO
from pymoo.core.callback import Callback
from pymoo.indicators.hv import HV
from pymoo.optimize import minimize

LOG = logging.getLogger(__name__)


def normalise_objectives(F: np.ndarray, f_target: float) -> np.ndarray:
    """Fixed normalisation for hypervolume: (-FBW/100, IL/30 dB, tau*f_t/10 cycles).

    The scales are fixed constants (not data-dependent) so that hypervolumes from different runs,
    seeds and algorithms are directly comparable. Reference point (0, 1, 1).
    """
    F = np.atleast_2d(F)
    return np.column_stack([F[:, 0] / 100.0, F[:, 1] / 30.0, F[:, 2] * 1e-6 * f_target / 10.0])


HV_REF = np.array([0.0, 1.0, 1.0])


def hypervolume(F: np.ndarray, f_target: float) -> float:
    if F is None or len(F) == 0:
        return 0.0
    Fn = normalise_objectives(F, f_target)
    Fn = Fn[np.all(Fn < HV_REF, axis=1)]
    return float(HV(ref_point=HV_REF)(Fn)) if len(Fn) else 0.0


class _SingleHistory(Callback):
    def __init__(self) -> None:
        super().__init__()
        self.best: list[float] = []
        self.n_evals: list[int] = []
        self.feasible_fraction: list[float] = []

    def notify(self, algorithm):
        pop = algorithm.pop
        cv = pop.get("CV").ravel()
        F = pop.get("F").ravel()
        feas = cv <= 0
        self.feasible_fraction.append(float(feas.mean()))
        opt = algorithm.opt
        best = float(opt.get("F").min()) if opt is not None and opt.get("CV").min() <= 0 else np.nan
        self.best.append(best)
        self.n_evals.append(int(algorithm.evaluator.n_eval))
        del F


class _ParetoHistory(Callback):
    def __init__(self, f_target: float) -> None:
        super().__init__()
        self.f_target = f_target
        self.hv: list[float] = []
        self.n_evals: list[int] = []

    def notify(self, algorithm):
        pop = algorithm.pop
        F = pop.get("F")[pop.get("CV").ravel() <= 0]
        self.hv.append(hypervolume(F, self.f_target))
        self.n_evals.append(int(algorithm.evaluator.n_eval))


@dataclass
class RunResult:
    algorithm: str
    seed: int
    x_best: np.ndarray | None
    f_best: np.ndarray | None
    feasible: bool
    final_population_x: np.ndarray
    final_population_f: np.ndarray
    final_population_cv: np.ndarray
    history_best: list[float] = field(default_factory=list)
    history_evals: list[int] = field(default_factory=list)
    history_feasible: list[float] = field(default_factory=list)
    history_hv: list[float] = field(default_factory=list)
    wall_time_s: float = 0.0
    n_evals: int = 0


def run_single(problem, algorithm: str, pop_size: int, n_gen: int, seed: int) -> RunResult:
    """Run GA or PSO on a single-objective problem."""
    if algorithm == "GA":
        algo = GA(pop_size=pop_size, eliminate_duplicates=True)
    elif algorithm == "PSO":
        algo = PSO(pop_size=pop_size)
    else:
        raise ValueError("algorithm must be 'GA' or 'PSO'")
    cb = _SingleHistory()
    t0 = time.perf_counter()
    res = minimize(problem, algo, ("n_gen", n_gen), seed=seed, callback=cb, verbose=False)
    wall = time.perf_counter() - t0
    feasible = res.X is not None and res.CV is not None and float(np.min(res.CV)) <= 0
    LOG.info("%s seed %d: best %s, feasible %s, %.1f s", algorithm, seed, res.F, feasible, wall)
    return RunResult(algorithm, seed, None if res.X is None else np.atleast_2d(res.X)[0],
                     None if res.F is None else np.atleast_1d(res.F), feasible,
                     res.pop.get("X"), res.pop.get("F"), res.pop.get("CV").ravel(),
                     cb.best, cb.n_evals, cb.feasible_fraction, [], wall, int(res.algorithm.evaluator.n_eval))


def run_nsga2(problem, pop_size: int, n_gen: int, seed: int, f_target: float,
              initial_x: np.ndarray | None = None) -> RunResult:
    """Run NSGA-II; returns the feasible non-dominated set as x_best/f_best."""
    kwargs = {}
    if initial_x is not None:
        from pymoo.core.population import Population

        rng = np.random.default_rng(seed)
        extra = rng.random((max(pop_size - len(initial_x), 0), problem.n_var))
        kwargs["sampling"] = Population.new(X=np.vstack([initial_x, extra])[:pop_size])
    algo = NSGA2(pop_size=pop_size, eliminate_duplicates=True, **kwargs)
    cb = _ParetoHistory(f_target)
    t0 = time.perf_counter()
    res = minimize(problem, algo, ("n_gen", n_gen), seed=seed, callback=cb, verbose=False)
    wall = time.perf_counter() - t0
    X, F = feasible_front(res.pop.get("X"), res.pop.get("F"), res.pop.get("CV").ravel())
    if res.opt is not None:  # the archive of the run can hold more non-dominated designs than the last population
        Xo, Fo = feasible_front(res.opt.get("X"), res.opt.get("F"), res.opt.get("CV").ravel())
        X, F = feasible_front(np.vstack([X, Xo]), np.vstack([F, Fo]), np.zeros(len(X) + len(Xo)))
    mask = np.ones(len(F), dtype=bool)
    LOG.info("NSGA-II seed %d: %d feasible non-dominated designs, HV %.4f, %.1f s",
             seed, len(F), cb.hv[-1] if cb.hv else 0.0, wall)
    return RunResult("NSGA-II", seed, X, F, bool(mask.any()), res.pop.get("X"), res.pop.get("F"),
                     res.pop.get("CV").ravel(), [], cb.n_evals, [], cb.hv, wall,
                     int(res.algorithm.evaluator.n_eval))


def feasible_front(X: np.ndarray, F: np.ndarray, CV: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Feasible, non-dominated, de-duplicated subset of (X, F)."""
    from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting

    X, F = np.atleast_2d(X), np.atleast_2d(F)
    keep = np.asarray(CV).ravel() <= 0
    X, F = X[keep], F[keep]
    if len(F) == 0:
        return np.empty((0, X.shape[1] if X.ndim == 2 else 0)), np.empty((0, F.shape[1] if F.ndim == 2 else 3))
    _, uniq = np.unique(np.round(F, 9), axis=0, return_index=True)
    X, F = X[np.sort(uniq)], F[np.sort(uniq)]
    front = NonDominatedSorting().do(F, only_non_dominated_front=True)
    return X[front], F[front]


def population_diversity(X: np.ndarray) -> float:
    """Mean pairwise Euclidean distance in the encoded unit hypercube."""
    X = np.atleast_2d(X)
    if len(X) < 2:
        return 0.0
    d = np.sqrt(((X[:, None, :] - X[None, :, :]) ** 2).sum(-1))
    return float(d[np.triu_indices(len(X), 1)].mean())


REQUIREMENTS = {
    # application key -> (priority, rule parameters); ASSUMPTIONS B7. The priorities follow the
    # resolution-penetration trade-off stated in the AIUM scrotal practice parameter (2025); the
    # numerical thresholds are design assumptions, not sourced values.
    "abdominal": ("sensitivity", {"fbw_min_pct": 60.0}),
    "general": ("balanced", {"il_margin_db": 3.0}),
    "superficial": ("resolution", {"il_margin_db": 6.0}),
}


def select_for_application(F: np.ndarray, app_key: str, f_target: float) -> int:
    """Pick one design from a front according to the application's stated priority.

    * sensitivity: lowest insertion loss among designs with FBW >= fbw_min_pct (deep imaging,
      penetration-limited); falls back to the widest-band design if none qualifies.
    * balanced:    ``select_recommended`` (widest band with IL within il_margin_db of the minimum).
    * resolution:  shortest pulse in cycles of f_target among designs with IL within
      il_margin_db of the minimum (superficial imaging, resolution-limited).
    """
    F = np.atleast_2d(F)
    priority, p = REQUIREMENTS.get(app_key, ("balanced", {"il_margin_db": 3.0}))
    if priority == "balanced":
        return select_recommended(F, p["il_margin_db"])
    if priority == "sensitivity":
        ok = np.nonzero(-F[:, 0] >= p["fbw_min_pct"])[0]
        if ok.size == 0:
            return int(np.argmin(F[:, 0]))
        return int(ok[np.lexsort((F[ok, 0], F[ok, 1]))[0]])
    ok = np.nonzero(F[:, 1] <= F[:, 1].min() + p["il_margin_db"])[0]
    cycles = F[ok, 2] * 1e-6 * f_target
    return int(ok[np.lexsort((F[ok, 1], cycles))[0]])


def select_recommended(F: np.ndarray, il_margin_db: float = 3.0) -> int:
    """Stated selection rule (DECISION D20): the largest-bandwidth design whose insertion loss
    is within ``il_margin_db`` of the lowest insertion loss on the front; ties broken by the
    shorter pulse."""
    F = np.atleast_2d(F)
    ok = np.nonzero(F[:, 1] <= F[:, 1].min() + il_margin_db)[0]
    order = np.lexsort((F[ok, 2], F[ok, 0]))  # primary: -FBW ascending, secondary: tau
    return int(ok[order[0]])
