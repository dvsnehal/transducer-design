"""Objective and constraint definitions (framework section 8, DECISIONS D08, D09, D11).

Pareto problem      minimise ( -FBW6_pe, IL2(fc), tau20 )
                    s.t. |fc - f_t|/f_t <= tol, ripple <= r_max, manufacturable, valid band
epsilon-constraint  minimise -FBW6_pe
                    s.t. the same constraints and IL2(fc) <= eps_IL, tau20 <= tau_max
Robust variants     objectives and constraints replaced by means over a fixed perturbation set
                    (common random numbers), optionally a percentile instead of the mean.

No weighted sum appears anywhere.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from pymoo.core.problem import Problem

from ustx.models import make_grid
from ustx.optimisation.design_space import N_VAR, DesignSpace
from ustx.performance import evaluate

# values assigned to an invalid design (no -6 dB band inside the grid): clearly dominated
INVALID_F = np.array([0.0, 60.0, 50.0])
INVALID_G_VALUE = 10.0


@dataclass(frozen=True)
class ObjectiveRecord:
    fbw6: float
    il2: float
    tau20_us: float
    fc_dev: float
    ripple: float
    manuf: float
    valid: bool


class Evaluator:
    """Evaluates encoded vectors; counts evaluations; shares one frequency grid."""

    def __init__(self, space: DesignSpace, n_grid: int = 2048, fmax_factor: float = 4.0):
        self.space = space
        self.grid = make_grid(space.app.f_target, n_grid, fmax_factor)
        self.n_evals = 0

    def record(self, design) -> ObjectiveRecord:
        self.n_evals += 1
        m = evaluate(design, self.space.app.f_target, self.grid, with_resonances=False)
        manuf = self.space.manufacturable(design)
        if not m.valid or not math.isfinite(m.tau20_us):
            return ObjectiveRecord(0.0, INVALID_F[1], INVALID_F[2], 1.0, 99.0, manuf, False)
        fc_dev = abs(m.fc_mhz * 1e6 - self.space.app.f_target) / self.space.app.f_target
        return ObjectiveRecord(m.fbw6_pe_pct, m.il2_db_at_fc, m.tau20_us, fc_dev, m.ripple_db, manuf, True)

    def objectives(self, rec: ObjectiveRecord) -> tuple[np.ndarray, np.ndarray]:
        app = self.space.app
        if not rec.valid:
            return INVALID_F.copy(), np.full(3, INVALID_G_VALUE)
        f = np.array([-rec.fbw6, rec.il2, rec.tau20_us])
        g = np.array([rec.fc_dev - app.fc_tolerance, rec.ripple - app.ripple_max_db, rec.manuf])
        return f, g


class ParetoProblem(Problem):
    """Three-objective problem for NSGA-II."""

    def __init__(self, space: DesignSpace, evaluator: Evaluator | None = None):
        super().__init__(n_var=N_VAR, n_obj=3, n_ieq_constr=3, xl=0.0, xu=1.0)
        self.space = space
        self.ev = evaluator or Evaluator(space)

    def _evaluate(self, x, out, *args, **kwargs):
        fs, gs = [], []
        for xi in np.atleast_2d(x):
            f, g = self.ev.objectives(self.ev.record(self.space.to_design(xi)))
            fs.append(f)
            gs.append(g)
        out["F"] = np.array(fs)
        out["G"] = np.array(gs)


class EpsilonConstraintProblem(Problem):
    """Single objective: maximise FBW6 subject to IL2 <= eps_il and tau20 <= tau_max."""

    def __init__(self, space: DesignSpace, eps_il_db: float, tau_max_us: float,
                 evaluator: Evaluator | None = None):
        super().__init__(n_var=N_VAR, n_obj=1, n_ieq_constr=5, xl=0.0, xu=1.0)
        self.space = space
        self.eps_il_db = eps_il_db
        self.tau_max_us = tau_max_us
        self.ev = evaluator or Evaluator(space)

    def _evaluate(self, x, out, *args, **kwargs):
        fs, gs = [], []
        for xi in np.atleast_2d(x):
            rec = self.ev.record(self.space.to_design(xi))
            f, g = self.ev.objectives(rec)
            fs.append([f[0]])
            if rec.valid:
                gs.append(np.concatenate([g, [rec.il2 - self.eps_il_db, rec.tau20_us - self.tau_max_us]]))
            else:
                gs.append(np.full(5, INVALID_G_VALUE))
        out["F"] = np.array(fs)
        out["G"] = np.array(gs)


class RobustParetoProblem(Problem):
    """Mean (or percentile) objectives over a fixed set of perturbed designs (Deb and Gupta 2006, type I).

    ``perturb(design, sample_row) -> design`` applies one tolerance sample; ``samples`` is fixed
    for the whole run (common random numbers). Constraints use the same statistic as the
    objectives, plus a cap on the fraction of perturbed designs without a valid band.
    """

    def __init__(self, space: DesignSpace, samples: np.ndarray, perturb, statistic: str = "mean",
                 percentile: float = 90.0, max_invalid_fraction: float = 0.05,
                 evaluator: Evaluator | None = None):
        super().__init__(n_var=N_VAR, n_obj=3, n_ieq_constr=4, xl=0.0, xu=1.0)
        if statistic not in {"mean", "percentile"}:
            raise ValueError("statistic must be 'mean' or 'percentile'")
        self.space = space
        self.samples = samples
        self.perturb = perturb
        self.statistic = statistic
        self.percentile = percentile
        self.max_invalid = max_invalid_fraction
        self.ev = evaluator or Evaluator(space)

    def robust_objectives(self, x: np.ndarray) -> tuple[np.ndarray, np.ndarray, dict]:
        nominal = self.space.to_design(x)
        recs = [self.ev.record(self.perturb(nominal, row)) for row in self.samples]
        valid = np.array([r.valid for r in recs])
        app = self.space.app
        if valid.mean() < 1 - self.max_invalid - 1e-12 or not valid.any():
            return INVALID_F.copy(), np.full(4, INVALID_G_VALUE), {"valid_fraction": float(valid.mean())}
        arr = np.array([[-r.fbw6, r.il2, r.tau20_us, r.fc_dev, r.ripple] for r in recs if r.valid])
        if self.statistic == "mean":
            stat = arr.mean(axis=0)
        else:  # pessimistic percentile: low FBW, high IL, long pulse, large deviations
            stat = np.percentile(arr, self.percentile, axis=0)
        f = stat[:3]
        g = np.array([stat[3] - app.fc_tolerance, stat[4] - app.ripple_max_db,
                      self.space.manufacturable(nominal), (1 - valid.mean()) - self.max_invalid])
        info = {"valid_fraction": float(valid.mean()), "std": arr.std(axis=0)}
        return f, g, info

    def _evaluate(self, x, out, *args, **kwargs):
        fs, gs = [], []
        for xi in np.atleast_2d(x):
            f, g, _ = self.robust_objectives(xi)
            fs.append(f)
            gs.append(g)
        out["F"] = np.array(fs)
        out["G"] = np.array(gs)
