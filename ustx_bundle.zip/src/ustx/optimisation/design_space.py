"""Design space: mixed categorical/continuous variables encoded on the unit hypercube.

Every variable is a real number in [0, 1]. Categorical variables are decoded by
``floor(x * K)`` (clipped to K - 1), so each category occupies an equal share of the interval;
GA and PSO therefore act on exactly the same encoding (DECISION D19).

Variables (index: meaning)
 0 piezoelectric material                    categorical over ``piezo_ids``
 1 plate thickness scale s                   t = s * v / (2 f_target),  s in [s_min, s_max]
 2 number of front matching layers           categorical over ``n_layer_options``
 3-5 matching material of layers 1-3         categorical over ``matching_ids`` (inner -> outer)
 6-8 layer thickness q_i                     d_i = q_i * lambda_i / 4 at f_target, q in [q_min, q_max]
 9 backing material (half-space)             categorical over ``backing_ids``
10 tuning network                            categorical over ('none', 'series_L', 'shunt_L')
11 tuning inductance factor kappa            L = kappa / (w_t^2 C0), kappa log-uniform in [k_min, k_max]

Element area is fixed per application (ASSUMPTIONS B3): a disc of diameter
``aperture_wavelengths`` tissue wavelengths at the target frequency.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ustx import EPS0
from ustx.acoustics import Layer, layer_from_material
from ustx.materials import MaterialDatabase, default_database
from ustx.models import Electrical, TransducerDesign

N_VAR = 12
TUNINGS = ("none", "series_L", "shunt_L")


@dataclass(frozen=True)
class Application:
    """Clinical application: target frequency and derived geometry (ASSUMPTIONS B1, B3)."""

    key: str
    name: str
    f_target: float
    aperture_wavelengths: float = 20.0
    tissue_z: float = 1.54e6
    tissue_c: float = 1540.0
    fc_tolerance: float = 0.05
    ripple_max_db: float = 3.0

    @property
    def aperture_diameter(self) -> float:
        return self.aperture_wavelengths * self.tissue_c / self.f_target

    @property
    def area(self) -> float:
        return math.pi * self.aperture_diameter**2 / 4


APPLICATIONS: dict[str, Application] = {
    "abdominal": Application("abdominal", "Abdominal imaging", 3.5e6),
    "general": Application("general", "General soft-tissue imaging", 7.5e6),
    "superficial": Application("superficial", "Superficial imaging", 12.0e6),
}


@dataclass
class DesignSpace:
    """Bounds, category lists and decoding for one application."""

    app: Application
    db: MaterialDatabase = field(default_factory=default_database)
    piezo_ids: tuple[str, ...] | None = None
    matching_ids: tuple[str, ...] | None = None
    backing_ids: tuple[str, ...] | None = None
    n_layer_options: tuple[int, ...] = (1, 2, 3)
    s_bounds: tuple[float, float] = (0.55, 1.15)
    q_bounds: tuple[float, float] = (0.6, 1.4)
    kappa_bounds: tuple[float, float] = (0.25, 4.0)
    tunings: tuple[str, ...] = TUNINGS
    min_layer_thickness: float = 10e-6  # manufacturing limit (ASSUMPTIONS B6)
    min_plate_thickness: float = 50e-6  # handling limit (ASSUMPTIONS B6)
    source_resistance: float = 50.0
    receiver_resistance: float = 50.0

    def __post_init__(self) -> None:
        if self.piezo_ids is None:
            # materials whose results would only be an upper bound are excluded from optimisation
            self.piezo_ids = tuple(k for k, m in self.db.piezo.items()
                                   if not any("upper bound" in fl for fl in m.flags))
        if self.matching_ids is None:
            self.matching_ids = tuple(m.material_id for m in self.db.by_role("matching"))
        if self.backing_ids is None:
            self.backing_ids = tuple(m.material_id for m in self.db.by_role("backing"))
        for pid in self.piezo_ids:
            if pid not in self.db.piezo:
                raise KeyError(f"unknown or non-simulatable piezo material {pid}")

    # ------------------------------------------------------------------ decoding
    @staticmethod
    def _cat(x: float, options: tuple) -> object:
        return options[min(int(math.floor(float(x) * len(options))), len(options) - 1)]

    @staticmethod
    def _lin(x: float, bounds: tuple[float, float]) -> float:
        return bounds[0] + float(x) * (bounds[1] - bounds[0])

    def decode(self, x: np.ndarray) -> dict:
        """Translate an encoded vector into named design choices."""
        x = np.clip(np.asarray(x, dtype=float), 0.0, 1.0)
        n_layers = int(self._cat(x[2], self.n_layer_options))
        lo, hi = self.kappa_bounds
        return {
            "piezo": self._cat(x[0], self.piezo_ids),
            "s": self._lin(x[1], self.s_bounds),
            "n_layers": n_layers,
            "matching": [self._cat(x[3 + i], self.matching_ids) for i in range(n_layers)],
            "q": [self._lin(x[6 + i], self.q_bounds) for i in range(n_layers)],
            "backing": self._cat(x[9], self.backing_ids),
            "tuning": self._cat(x[10], self.tunings),
            "kappa": float(lo * (hi / lo) ** x[11]),
        }

    def build(self, choice: dict) -> TransducerDesign:
        """Construct the physical design from decoded choices."""
        ft = self.app.f_target
        pz = self.db.piezo[choice["piezo"]]
        thickness = choice["s"] * pz.velocity / (2 * ft)
        layers: list[Layer] = []
        for mid, q in zip(choice["matching"], choice["q"]):
            layers.append(layer_from_material(self.db.passive[mid], frequency=ft, quarter_waves=q))
        backing = self.db.passive[choice["backing"]]
        el = Electrical(self.source_resistance, self.receiver_resistance)
        if choice["tuning"] != "none":
            c0 = pz.eps33s_rel * EPS0 * self.app.area / thickness
            inductance = choice["kappa"] / ((2 * math.pi * ft) ** 2 * c0)
            el = Electrical(self.source_resistance, self.receiver_resistance, choice["tuning"], inductance)
        return TransducerDesign(pz, thickness, self.app.area, tuple(layers), backing.z_specific,
                                load_z=self.app.tissue_z, electrical=el, name=self.label(choice))

    def to_design(self, x: np.ndarray) -> TransducerDesign:
        return self.build(self.decode(x))

    def manufacturable(self, design: TransducerDesign) -> float:
        """Constraint value (<= 0 feasible): thinnest layer/plate relative to the limits."""
        viol = self.min_plate_thickness / design.thickness - 1
        for L in design.front_layers:
            viol = max(viol, self.min_layer_thickness / L.thickness - 1)
        return viol

    def label(self, choice: dict) -> str:
        layers = "+".join(f"{m}({q:.2f}q)" for m, q in zip(choice["matching"], choice["q"]))
        tune = "" if choice["tuning"] == "none" else f", {choice['tuning']} k={choice['kappa']:.2f}"
        return f"{choice['piezo']} s={choice['s']:.3f} | {layers} | {choice['backing']}{tune}"

    def encode(self, piezo: str, s: float, matching: list[str], q: list[float], backing: str,
               tuning: str = "none", kappa: float = 1.0) -> np.ndarray:
        """Inverse of ``decode`` (centre of each category), for seeding and tests."""
        def cat(value, options):
            return (options.index(value) + 0.5) / len(options)

        x = np.full(N_VAR, 0.5)
        x[0] = cat(piezo, self.piezo_ids)
        x[1] = (s - self.s_bounds[0]) / (self.s_bounds[1] - self.s_bounds[0])
        x[2] = cat(len(matching), self.n_layer_options)
        for i, (m, qi) in enumerate(zip(matching, q)):
            x[3 + i] = cat(m, self.matching_ids)
            x[6 + i] = (qi - self.q_bounds[0]) / (self.q_bounds[1] - self.q_bounds[0])
        x[9] = cat(backing, self.backing_ids)
        x[10] = cat(tuning, self.tunings)
        lo, hi = self.kappa_bounds
        x[11] = math.log(kappa / lo) / math.log(hi / lo)
        return x
