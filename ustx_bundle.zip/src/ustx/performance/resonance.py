"""Series, parallel and loaded resonances (framework section 2.4, terminology table)."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ustx.materials.database import PiezoMaterial, series_parallel_ratio
from ustx.models.piezo import plate_constants
from ustx.models.reference import zin_unloaded


@dataclass(frozen=True)
class UnloadedResonances:
    fs_lossless: float  # Hz, from Eq. 2.12
    fp_lossless: float  # Hz, Eq. 2.11
    f_max_conductance: float  # Hz, lossy plate
    f_max_resistance: float  # Hz, lossy plate
    kt_recovered: float  # Eq. 2.12 applied to the lossy extrema


@dataclass(frozen=True)
class LoadedExtrema:
    f_min_abs_z: float
    f_max_abs_z: float
    abs_z_min: float
    abs_z_max: float


def _refine_peak(f: np.ndarray, y: np.ndarray, i: int) -> float:
    """Parabolic interpolation of a sampled maximum."""
    if i <= 0 or i >= len(y) - 1:
        return float(f[i])
    y0, y1, y2 = y[i - 1], y[i], y[i + 1]
    den = y0 - 2 * y1 + y2
    if den == 0:
        return float(f[i])
    delta = 0.5 * (y0 - y2) / den
    return float(f[i] + delta * (f[i + 1] - f[i]))


def unloaded_resonances(material: PiezoMaterial, thickness: float, area: float = 1e-4,
                        n: int = 40001) -> UnloadedResonances:
    """Resonances of the free plate.

    The lossless values follow analytically; the lossy values are the extrema of conductance and
    resistance found on a fine grid around the fundamental and refined parabolically.
    """
    fp = material.velocity / (2 * thickness)
    fs = series_parallel_ratio(material.kt) * fp
    pc = plate_constants(material, thickness, area)
    f = np.linspace(0.6 * fp, 1.3 * fp, n)
    z = zin_unloaded(pc, f)
    g = np.real(1.0 / z)
    r = np.real(z)
    fg = _refine_peak(f, g, int(np.argmax(g)))
    fr = _refine_peak(f, r, int(np.argmax(r)))
    try:
        from ustx.materials.database import kt_from_resonances
        kt_rec = kt_from_resonances(fg, fr)
    except ValueError:
        kt_rec = math.nan
    return UnloadedResonances(fs, fp, fg, fr, kt_rec)


def loaded_extrema(f: np.ndarray, zin: np.ndarray, f_lo: float, f_hi: float) -> LoadedExtrema:
    """Loaded resonance (local minimum of |Z_in|) and anti-resonance (local maximum) in [f_lo, f_hi].

    Only *interior* local extrema count: a heavily damped or matched element whose |Z| falls
    monotonically has no distinct loaded resonance, and NaN is returned for it rather than the
    edge of the search window. When several local extrema exist, the deepest minimum and the
    highest maximum are reported.
    """
    mask = (f >= f_lo) & (f <= f_hi)
    if mask.sum() < 3:
        raise ValueError("search window contains fewer than three grid points")
    fw, zw = f[mask], np.abs(zin[mask])
    i = np.arange(1, len(zw) - 1)
    mins = i[(zw[i] < zw[i - 1]) & (zw[i] <= zw[i + 1])]
    maxs = i[(zw[i] > zw[i - 1]) & (zw[i] >= zw[i + 1])]
    nan = math.nan
    if mins.size:
        k = int(mins[np.argmin(zw[mins])])
        fmin, zmin = _refine_peak(fw, -zw, k), float(zw[k])
    else:
        fmin, zmin = nan, nan
    if maxs.size:
        k = int(maxs[np.argmax(zw[maxs])])
        fmax, zmax = _refine_peak(fw, zw, k), float(zw[k])
    else:
        fmax, zmax = nan, nan
    return LoadedExtrema(fmin, fmax, zmin, zmax)
