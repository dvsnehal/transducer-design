"""Time-domain pulse-echo response and pulse metrics (framework section 7).

h(t) = F^-1{ H_pe(f) E(f) } with E(f) = 1 (impulse excitation) unless stated otherwise.
The spectrum is defined on f_k = k df, k = 1..n; the DC sample is set to zero analytically
(H_pe -> 0 as f -> 0). A raised-cosine taper is applied over the top ``taper_fraction`` of the
band to suppress truncation ripple; its effect is part of the convergence study.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.signal import hilbert


@dataclass(frozen=True)
class PulseMetrics:
    duration_20db: float  # s, envelope above -20 dB of its peak (first to last crossing)
    ringdown_20db: float  # s, peak to last -20 dB crossing
    ringdown_40db: float  # s, peak to last -40 dB crossing
    window_ok: bool  # True if the envelope at the window edges is below -60 dB


def impulse_response(f: np.ndarray, h: np.ndarray, excitation: np.ndarray | None = None,
                     taper_fraction: float = 0.1) -> tuple[np.ndarray, np.ndarray]:
    """Return (t, h(t)) for a spectrum sampled on f_k = k df.

    The output is circularly shifted so that the envelope peak lies at the window centre; time
    therefore has an arbitrary origin and only durations are meaningful.
    """
    f = np.asarray(f, dtype=float)
    n = f.size
    df = f[1] - f[0]
    if not np.allclose(np.diff(f), df, rtol=1e-9, atol=0) or abs(f[0] - df) > 1e-9 * df:
        raise ValueError("time-domain conversion needs the uniform grid f_k = k df")
    spec = np.asarray(h, dtype=complex).copy()
    if excitation is not None:
        spec = spec * excitation
    if taper_fraction > 0:
        m = max(int(taper_fraction * n), 1)
        ramp = 0.5 * (1 + np.cos(np.linspace(0, np.pi, m)))
        spec[-m:] *= ramp
    full = np.concatenate(([0.0], spec))
    nfft = 2 * n
    sig = np.fft.irfft(full, n=nfft) * nfft * df
    env = np.abs(hilbert(sig))
    sig = np.roll(sig, nfft // 2 - int(np.argmax(env)))
    dt = 1.0 / (nfft * df)
    t = (np.arange(nfft) - nfft // 2) * dt
    return t, sig


def _crossing_time(t: np.ndarray, env_db: np.ndarray, i_from: int, i_to: int, level: float) -> float:
    """Linear interpolation of the level crossing between samples i_from (above) and i_to (below)."""
    a, b = env_db[i_from], env_db[i_to]
    if a == b:
        return float(t[i_from])
    frac = (a - level) / (a - b)
    return float(t[i_from] + frac * (t[i_to] - t[i_from]))


def pulse_metrics(t: np.ndarray, sig: np.ndarray) -> PulseMetrics:
    env = np.abs(hilbert(sig))
    peak = env.max()
    if peak <= 0:
        return PulseMetrics(np.nan, np.nan, np.nan, False)
    with np.errstate(divide="ignore"):
        env_db = 20 * np.log10(env / peak)
    ip = int(np.argmax(env))

    def last_above(level: float) -> float:
        above = np.nonzero(env_db >= level)[0]
        i = int(above[-1])
        if i >= len(env_db) - 1:
            return float(t[-1])
        return _crossing_time(t, env_db, i, i + 1, level)

    def first_above(level: float) -> float:
        above = np.nonzero(env_db >= level)[0]
        i = int(above[0])
        if i == 0:
            return float(t[0])
        return _crossing_time(t, env_db, i, i - 1, level)

    duration = last_above(-20.0) - first_above(-20.0)
    edge = max(env_db[: len(env_db) // 20].max(), env_db[-len(env_db) // 20:].max())
    return PulseMetrics(duration, last_above(-20.0) - t[ip], last_above(-40.0) - t[ip], bool(edge < -60))
