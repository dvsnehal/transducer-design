"""Frequency-domain performance metrics (framework section 6, DECISION D07).

All bandwidths are computed on a stated response and at a stated level; they are never mixed:

* fbw6_pe   -6 dB fractional bandwidth of |H_pe| (pulse-echo, two-way voltage)   [primary]
* fbw3_tx   -3 dB fractional bandwidth of |H_tx| (one-way transmit pressure)
* fbw3_rx   -3 dB fractional bandwidth of |H_rx| (one-way receive voltage)
* fbw3_pwr  -3 dB fractional bandwidth of G_tx (one-way transmit power)

Band edges are the outermost crossings of the contiguous region around the peak that stays
above the level; a region that reaches the edge of the grid is reported as invalid (NaN).
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass

import numpy as np

from ustx.models.transducer import Response, TransducerDesign, make_grid, simulate
from ustx.performance.resonance import loaded_extrema, unloaded_resonances
from ustx.performance.timedomain import impulse_response, pulse_metrics


@dataclass(frozen=True)
class Band:
    f_low: float
    f_high: float
    f_peak: float
    i_low: int
    i_high: int

    @property
    def centre(self) -> float:
        return 0.5 * (self.f_low + self.f_high)

    @property
    def fractional_percent(self) -> float:
        return 100.0 * (self.f_high - self.f_low) / self.centre


NAN_BAND = Band(math.nan, math.nan, math.nan, -1, -1)


def band_edges(f: np.ndarray, mag_db: np.ndarray, level_db: float, f_search_max: float | None = None) -> Band:
    """Edges of the contiguous region around the global peak that lies within ``level_db`` of it.

    ``mag_db`` must be normalised arbitrarily; the peak is found inside f <= f_search_max.
    """
    f = np.asarray(f)
    y = np.asarray(mag_db, dtype=float)
    lim = len(f) if f_search_max is None else int(np.searchsorted(f, f_search_max))
    if lim < 3 or not np.isfinite(y[:lim]).any():
        return NAN_BAND
    ip = int(np.nanargmax(y[:lim]))
    thr = y[ip] + level_db
    below = y < thr
    left = np.nonzero(below[:ip])[0]
    right = np.nonzero(below[ip:])[0]
    if left.size == 0 or right.size == 0:
        return NAN_BAND
    il = int(left[-1])  # last sample below threshold on the left
    ir = ip + int(right[0])  # first sample below threshold on the right

    def interp(i_below: int, i_above: int) -> float:
        y0, y1 = y[i_below], y[i_above]
        return float(f[i_below] + (thr - y0) / (y1 - y0) * (f[i_above] - f[i_below]))

    return Band(interp(il, il + 1), interp(ir, ir - 1), float(f[ip]), il + 1, ir - 1)


def passband_ripple_db(mag_db: np.ndarray, band: Band) -> float:
    """Largest dip (dB) below the band maximum between two local maxima inside the band."""
    if band.i_low < 0:
        return math.nan
    seg = np.asarray(mag_db[band.i_low: band.i_high + 1], dtype=float)
    if seg.size < 3:
        return 0.0
    interior = np.arange(1, seg.size - 1)
    is_min = (seg[interior] < seg[interior - 1]) & (seg[interior] <= seg[interior + 1])
    if not is_min.any():
        return 0.0
    return float(seg.max() - seg[interior][is_min].min())


@dataclass(frozen=True)
class Metrics:
    """Scalar performance summary of one design. Units are in the field names."""

    valid: bool
    fc_mhz: float
    f_peak_mhz: float
    fbw6_pe_pct: float
    fbw3_tx_pct: float
    fbw3_rx_pct: float
    fbw3_pwr_pct: float
    ripple_db: float
    il2_db_at_fc: float  # two-way insertion loss at fc (Eq. 5.6)
    il2_db_min: float  # minimum two-way insertion loss over the grid
    tx_sens_pa_per_v: float  # |H_tx| at fc
    rx_sens_uv_per_pa: float  # |H_rx| at fc, microvolt per pascal
    efficiency_at_fc: float  # acoustic power to load / electrical power accepted
    back_fraction_at_fc: float  # share of centre-tap power going to the rear
    zin_abs_ohm_at_fc: float
    zin_phase_deg_at_fc: float
    f_min_abs_z_mhz: float  # loaded resonance (minimum |Z|)
    f_max_abs_z_mhz: float  # loaded anti-resonance (maximum |Z|)
    fs_mhz: float  # unloaded series resonance (lossless, Eq. 2.12)
    fp_mhz: float  # unloaded parallel resonance (lossless, Eq. 2.11)
    tau20_us: float  # pulse-echo envelope duration above -20 dB
    ringdown20_us: float
    ringdown40_us: float
    window_ok: bool

    def as_dict(self) -> dict:
        return asdict(self)


def _interp_at(f: np.ndarray, y: np.ndarray, x: float) -> complex:
    return complex(np.interp(x, f, y.real) + 1j * np.interp(x, f, y.imag))


def evaluate(design: TransducerDesign, f_target: float, grid: np.ndarray | None = None,
             response: Response | None = None, with_time_domain: bool = True,
             with_resonances: bool = True) -> Metrics:
    """Compute every scalar metric of framework section 6 for ``design``."""
    f = make_grid(f_target) if grid is None else grid
    r = response if response is not None else simulate(design, f)
    with np.errstate(divide="ignore"):
        pe_db = 20 * np.log10(np.abs(r.h_pe))
        tx_db = 20 * np.log10(np.abs(r.h_tx))
        rx_db = 20 * np.log10(np.abs(r.h_rx))
        pw_db = 10 * np.log10(r.g_tx)
    search = 2.5 * f_target
    b6 = band_edges(f, pe_db, -6.0, search)
    nan = math.nan
    if not np.isfinite(b6.f_low):
        return Metrics(False, *([nan] * 22), False)
    fc = b6.centre
    btx = band_edges(f, tx_db, -3.0, search)
    brx = band_edges(f, rx_db, -3.0, search)
    bpw = band_edges(f, pw_db, -3.0, search)
    il = r.insertion_loss_db()
    zfc = _interp_at(f, r.zin, fc)

    fm = fn = fs = fp = nan
    if with_resonances:
        try:
            ext = loaded_extrema(f, r.zin, 0.4 * f_target, 1.8 * f_target)
            fm, fn = ext.f_min_abs_z / 1e6, ext.f_max_abs_z / 1e6
        except ValueError:
            pass
        ur = unloaded_resonances(design.piezo, design.thickness, design.area, n=4001)
        fs, fp = ur.fs_lossless / 1e6, ur.fp_lossless / 1e6

    tau = rd20 = rd40 = nan
    wok = False
    if with_time_domain:
        t, sig = impulse_response(f, r.h_pe)
        pm = pulse_metrics(t, sig)
        tau, rd20, rd40, wok = pm.duration_20db * 1e6, pm.ringdown_20db * 1e6, pm.ringdown_40db * 1e6, pm.window_ok

    return Metrics(
        valid=True,
        fc_mhz=fc / 1e6,
        f_peak_mhz=b6.f_peak / 1e6,
        fbw6_pe_pct=b6.fractional_percent,
        fbw3_tx_pct=btx.fractional_percent,
        fbw3_rx_pct=brx.fractional_percent,
        fbw3_pwr_pct=bpw.fractional_percent,
        ripple_db=passband_ripple_db(pe_db, b6),
        il2_db_at_fc=float(np.interp(fc, f, il)),
        il2_db_min=float(np.min(il[: int(np.searchsorted(f, search))])),
        tx_sens_pa_per_v=float(np.interp(fc, f, np.abs(r.h_tx))),
        rx_sens_uv_per_pa=float(np.interp(fc, f, np.abs(r.h_rx))) * 1e6,
        efficiency_at_fc=float(np.interp(fc, f, r.efficiency)),
        back_fraction_at_fc=float(np.interp(fc, f, r.power_back_fraction)),
        zin_abs_ohm_at_fc=abs(zfc),
        zin_phase_deg_at_fc=math.degrees(math.atan2(zfc.imag, zfc.real)),
        f_min_abs_z_mhz=fm,
        f_max_abs_z_mhz=fn,
        fs_mhz=fs,
        fp_mhz=fp,
        tau20_us=tau,
        ringdown20_us=rd20,
        ringdown40_us=rd40,
        window_ok=wok,
    )
