"""Monte Carlo, local (elasticity) and global (Sobol) sensitivity analysis."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import pandas as pd

from ustx.models import TransducerDesign, make_grid
from ustx.performance import evaluate
from ustx.robustness.tolerances import COLUMNS, ToleranceSpec, draw_samples, perturb

OUTPUTS = ("fc_mhz", "fbw6_pe_pct", "il2_db_at_fc", "tau20_us")


def _metrics_row(design: TransducerDesign, f_target: float, grid: np.ndarray) -> dict:
    m = evaluate(design, f_target, grid, with_resonances=False)
    return {k: getattr(m, k) for k in OUTPUTS} | {"valid": m.valid, "ripple_db": m.ripple_db}


def monte_carlo(design: TransducerDesign, f_target: float, n: int = 2000, seed: int = 1,
                spec: ToleranceSpec = ToleranceSpec(), grid: np.ndarray | None = None,
                samples: np.ndarray | None = None) -> pd.DataFrame:
    """Evaluate ``n`` perturbed copies of ``design``; one row per sample."""
    grid = make_grid(f_target) if grid is None else grid
    samples = draw_samples(n, seed) if samples is None else samples
    rows = [_metrics_row(perturb(design, s, spec), f_target, grid) for s in samples]
    return pd.DataFrame(rows)


@dataclass(frozen=True)
class Summary:
    output: str
    nominal: float
    mean: float
    std: float
    p05: float
    p95: float
    ci95_mean_low: float
    ci95_mean_high: float


def summarise(df: pd.DataFrame, nominal: dict) -> list[Summary]:
    """Mean, SD, 5-95 % range and a normal-approximation 95 % confidence interval of the mean."""
    out = []
    ok = df[df["valid"]]
    for k in OUTPUTS:
        x = ok[k].to_numpy(dtype=float)
        x = x[np.isfinite(x)]
        se = x.std(ddof=1) / math.sqrt(len(x))
        out.append(Summary(k, nominal[k], x.mean(), x.std(ddof=1), np.percentile(x, 5), np.percentile(x, 95),
                           x.mean() - 1.96 * se, x.mean() + 1.96 * se))
    return out


def yield_fraction(df: pd.DataFrame, f_target: float, fc_tolerance: float = 0.05,
                   fbw_min: float | None = None, il_max: float | None = None) -> float:
    """Fraction of samples that are valid and meet the stated specification."""
    ok = df["valid"] & (np.abs(df["fc_mhz"] * 1e6 - f_target) <= fc_tolerance * f_target)
    if fbw_min is not None:
        ok &= df["fbw6_pe_pct"] >= fbw_min
    if il_max is not None:
        ok &= df["il2_db_at_fc"] <= il_max
    return float(ok.mean())


def local_sensitivity(design: TransducerDesign, f_target: float, step: float = 0.01,
                      spec: ToleranceSpec = ToleranceSpec(), grid: np.ndarray | None = None) -> pd.DataFrame:
    """Normalised elasticities  E = (d y / y) / (d p / p)  by central differences of +/- ``step``.

    Also reports the 'tolerance-weighted' effect sigma_p * E * y, i.e. the change in each output
    for a one-sigma change of the parameter, which ranks parameters by practical importance.
    """
    grid = make_grid(f_target) if grid is None else grid
    base = _metrics_row(design, f_target, grid)
    n_layers = len(design.front_layers)
    fixed_load = spec.without_load()
    rows = []
    for col in COLUMNS[:-1]:
        if col.startswith("layer") and int(col[5]) > n_layers:
            continue
        sig = spec.sigma(col)
        if sig == 0:
            continue
        res = {}
        for sgn in (+1, -1):
            row = np.zeros(len(COLUMNS))
            row[COLUMNS.index(col)] = sgn * step / sig
            pert = perturb(design, row, fixed_load, nominal_load_z=design.load_z)
            res[sgn] = _metrics_row(pert, f_target, grid)
        rec = {"parameter": col, "sigma_rel": sig}
        for k in OUTPUTS:
            dy = (res[+1][k] - res[-1][k]) / (2 * step)
            rec[f"elasticity_{k}"] = dy / base[k] if base[k] else math.nan
            rec[f"one_sigma_{k}"] = dy * sig
        rows.append(rec)
    load_rec = {"parameter": "load_z", "sigma_rel": spec.load_rel_sd}
    up, dn = design.with_(load_z=design.load_z * (1 + step)), design.with_(load_z=design.load_z * (1 - step))
    ru, rd = _metrics_row(up, f_target, grid), _metrics_row(dn, f_target, grid)
    for k in OUTPUTS:
        dy = (ru[k] - rd[k]) / (2 * step)
        load_rec[f"elasticity_{k}"] = dy / base[k] if base[k] else math.nan
        load_rec[f"one_sigma_{k}"] = dy * load_rec["sigma_rel"]
    rows.append(load_rec)
    return pd.DataFrame(rows)


def sobol_indices(design: TransducerDesign, f_target: float, n_base: int = 512, seed: int = 7,
                  spec: ToleranceSpec = ToleranceSpec(), grid: np.ndarray | None = None) -> pd.DataFrame:
    """First-order and total Sobol indices (Saltelli 2010 estimators via SALib).

    Each input is the standard-normal draw of one tolerance column, mapped through the inverse
    normal CDF from a uniform Sobol sequence (truncated to +/-3 sigma); the load uses its own
    uniform range. Inputs with zero sigma or absent layers are omitted.
    """
    from SALib.analyze import sobol as sobol_analyze
    from SALib.sample import sobol as sobol_sample
    from scipy.stats import norm

    grid = make_grid(f_target) if grid is None else grid
    n_layers = len(design.front_layers)
    names = [c for c in COLUMNS if c == "load_z" or (spec.sigma(c) > 0 and not (
        c.startswith("layer") and int(c[5]) > n_layers))]
    problem = {"num_vars": len(names), "names": names, "bounds": [[0.00135, 0.99865]] * len(names)}
    u = sobol_sample.sample(problem, n_base, calc_second_order=False, seed=seed)
    rows = np.zeros((len(u), len(COLUMNS)))
    for j, name in enumerate(names):
        idx = COLUMNS.index(name)
        rows[:, idx] = u[:, j] if name == "load_z" else norm.ppf(u[:, j])
    if "load_z" not in names:
        rows[:, -1] = 0.5
    Y = pd.DataFrame([_metrics_row(perturb(design, r, spec), f_target, grid) for r in rows])
    out = []
    for k in OUTPUTS:
        y = Y[k].to_numpy(dtype=float)
        if not np.all(np.isfinite(y)):
            y = np.where(np.isfinite(y), y, np.nanmean(y))
        si = sobol_analyze.analyze(problem, y, calc_second_order=False, seed=seed)
        for j, name in enumerate(names):
            out.append({"output": k, "parameter": name, "S1": si["S1"][j], "S1_conf": si["S1_conf"][j],
                        "ST": si["ST"][j], "ST_conf": si["ST_conf"][j]})
    df = pd.DataFrame(out)
    df.attrs["n_model_runs"] = len(rows)
    df.attrs["n_invalid"] = int((~Y["valid"]).sum())
    return df
