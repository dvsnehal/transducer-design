"""Tolerance model: which quantities vary, by how much, and how a sample perturbs a design.

Each perturbed quantity is multiplied by (1 + sigma * z) with z a standard normal truncated at
+/-3 (so no factor can become non-positive for the sigmas used), except
* Qm, which is lognormal: Qm * exp(sigma * z), and
* the tissue load, which is drawn uniformly between the fat and blood impedances.

Default standard deviations and their basis (ASSUMPTIONS D1-D9):

group          quantity                    sigma   basis
manufacturing  plate thickness             1 %     assumed lapping tolerance
manufacturing  matching-layer thickness    5 %     assumed casting/lapping tolerance (per layer)
material       piezo stiffness c33D        5 %     APC frequency tolerance +/-5 % transferred (velocity^2)
material       clamped permittivity        10 %    APC capacitance tolerance +/-20 % as +/-2 sigma
material       coupling kt                 3 %     assumed
material       Qm (lognormal)              20 %    assumed
material       matching-layer impedance    5 %     assumed; Onda vs Chen E-Solder differ by 15 %
material       backing impedance           5 %     assumed
loading        tissue impedance            U[1.38, 1.66] MRayl  fat to blood (Rathod 2020)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, replace

import numpy as np

from ustx.models import TransducerDesign

MAX_LAYERS = 3

# Column layout of a sample row (standard-normal draws except the last, which is U[0, 1]).
COLUMNS: tuple[str, ...] = (
    "plate_thickness", "c33d", "eps33s", "kt", "qm", "backing_z",
    "layer1_thickness", "layer2_thickness", "layer3_thickness",
    "layer1_z", "layer2_z", "layer3_z",
    "load_z",
)
FIELD_COLUMNS = {
    "plate_thickness": ("plate_thickness",),
    "layer_thickness": ("layer1_thickness", "layer2_thickness", "layer3_thickness"),
    "c33d": ("c33d",),
    "eps33s": ("eps33s",),
    "kt": ("kt",),
    "qm": ("qm",),
    "layer_z": ("layer1_z", "layer2_z", "layer3_z"),
    "backing_z": ("backing_z",),
}
GROUPS = {
    "manufacturing": ("plate_thickness", "layer1_thickness", "layer2_thickness", "layer3_thickness"),
    "material": ("c33d", "eps33s", "kt", "qm", "backing_z", "layer1_z", "layer2_z", "layer3_z"),
    "loading": ("load_z",),
}


@dataclass(frozen=True)
class ToleranceSpec:
    plate_thickness: float = 0.01
    layer_thickness: float = 0.05
    c33d: float = 0.05
    eps33s: float = 0.10
    kt: float = 0.03
    qm: float = 0.20
    layer_z: float = 0.05
    backing_z: float = 0.05
    load_z_range: tuple[float, float] = (1.38e6, 1.66e6)

    def sigma(self, column: str) -> float:
        if column.startswith("layer") and column.endswith("_thickness"):
            return self.layer_thickness
        if column.startswith("layer") and column.endswith("_z"):
            return self.layer_z
        return float(getattr(self, column))

    @property
    def load_rel_sd(self) -> float:
        """Relative standard deviation of the uniform load: (hi - lo) / sqrt(12) / mean."""
        lo, hi = self.load_z_range
        return (hi - lo) / math.sqrt(12) / (0.5 * (lo + hi))

    def without_load(self) -> ToleranceSpec:
        """Copy that keeps the nominal load impedance."""
        return replace(self, load_z_range=(math.nan, math.nan))

    def only(self, groups: tuple[str, ...]) -> ToleranceSpec:
        """Copy in which every group not listed is switched off (sigma 0, nominal load)."""
        keep = {c for g in groups for c in GROUPS[g]}
        changes = {name: 0.0 for name, cols in FIELD_COLUMNS.items() if not keep.intersection(cols)}
        spec = replace(self, **changes)
        return spec if "load_z" in keep else spec.without_load()


def draw_samples(n: int, seed: int) -> np.ndarray:
    """Common random numbers: (n, len(COLUMNS)) array; truncated normals and one uniform."""
    rng = np.random.default_rng(seed)
    z = rng.standard_normal((n, len(COLUMNS)))
    while True:
        bad = np.abs(z[:, :-1]) > 3
        if not bad.any():
            break
        z[:, :-1][bad] = rng.standard_normal(int(bad.sum()))
    z[:, -1] = rng.random(n)
    return z


def perturb(design: TransducerDesign, row: np.ndarray, spec: ToleranceSpec = ToleranceSpec(),
            nominal_load_z: float | None = None) -> TransducerDesign:
    """Apply one sample row to ``design`` and return the perturbed design."""
    v = dict(zip(COLUMNS, row))

    def fac(col: str) -> float:
        return 1.0 + spec.sigma(col) * v[col]

    pz = design.piezo
    qm = pz.qm if math.isinf(pz.qm) else pz.qm * math.exp(spec.qm * v["qm"])
    kt = min(pz.kt * fac("kt"), 0.95)
    new_pz = pz.with_overrides(c33d=pz.c33d * fac("c33d"), eps33s_rel=pz.eps33s_rel * fac("eps33s"),
                               kt=kt, qm=qm)
    layers = tuple(
        L.scaled(thickness_factor=fac(f"layer{i + 1}_thickness"), z_factor=fac(f"layer{i + 1}_z"))
        for i, L in enumerate(design.front_layers[:MAX_LAYERS])
    ) + tuple(design.front_layers[MAX_LAYERS:])
    lo, hi = spec.load_z_range
    if math.isnan(lo):
        load = design.load_z if nominal_load_z is None else nominal_load_z
    else:
        load = lo + (hi - lo) * v["load_z"]
    return replace(design, piezo=new_pz, thickness=design.thickness * fac("plate_thickness"),
                   front_layers=layers, backing_z=design.backing_z * fac("backing_z"), load_z=load)


def make_perturber(spec: ToleranceSpec = ToleranceSpec()):
    """Closure suitable for ``RobustParetoProblem``."""
    def _p(design: TransducerDesign, row: np.ndarray) -> TransducerDesign:
        return perturb(design, row, spec)
    return _p
