"""Transmission-line model of passive layers (framework Eqs. 4.1-4.4).

Convention: exp(+j w t); force F and particle velocity u positive in the direction of
propagation towards the load; mechanical impedances in N s/m (specific impedance x area).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, replace

import numpy as np

from ustx.materials.database import NP_PER_DB, PassiveMaterial

ArrayLike = np.ndarray | float


@dataclass(frozen=True)
class Layer:
    """A uniform passive layer.

    Attributes
    ----------
    name: label for plots and reports.
    z_specific: specific acoustic impedance rho*v (Rayl).
    velocity: phase velocity (m/s); assumed non-dispersive (ASSUMPTIONS A8).
    thickness: m.
    alpha0: attenuation (Np/m) at ``f_alpha``.
    f_alpha: reference frequency of ``alpha0`` (Hz).
    alpha_exp: power-law exponent n in alpha = alpha0 (f/f_alpha)^n.
    """

    name: str
    z_specific: float
    velocity: float
    thickness: float
    alpha0: float = 0.0
    f_alpha: float = 1e6
    alpha_exp: float = 1.0

    def __post_init__(self) -> None:
        if self.z_specific <= 0:
            raise ValueError(f"{self.name}: impedance must be positive")
        if self.velocity <= 0:
            raise ValueError(f"{self.name}: velocity must be positive")
        if self.thickness < 0:
            raise ValueError(f"{self.name}: thickness must be non-negative")
        if self.alpha0 < 0:
            raise ValueError(f"{self.name}: attenuation must be non-negative")

    @property
    def density(self) -> float:
        return self.z_specific / self.velocity

    def scaled(self, thickness_factor: float = 1.0, z_factor: float = 1.0,
               velocity_factor: float = 1.0) -> Layer:
        """Copy with thickness, impedance or velocity scaled (used for tolerances)."""
        return replace(self, thickness=self.thickness * thickness_factor,
                       z_specific=self.z_specific * z_factor,
                       velocity=self.velocity * velocity_factor)


def quarter_wave_thickness(velocity: float, frequency: float) -> float:
    """lambda/4 at ``frequency`` (m)."""
    return velocity / (4.0 * frequency)


def layer_from_material(material: PassiveMaterial, thickness: float | None = None, *,
                        frequency: float | None = None, quarter_waves: float = 1.0,
                        alpha_exp: float = 1.0) -> Layer:
    """Build a layer from a database material.

    Either give ``thickness`` directly or give ``frequency`` and the number of quarter
    wavelengths at that frequency.
    """
    if material.velocity is None:
        raise ValueError(f"{material.material_id}: velocity required for a finite layer")
    if thickness is None:
        if frequency is None:
            raise ValueError("give thickness or frequency")
        thickness = quarter_waves * quarter_wave_thickness(material.velocity, frequency)
    alpha0, f_alpha = 0.0, 1e6
    if material.atten_db_per_cm and material.atten_freq_hz:
        alpha0 = material.atten_db_per_cm * 100.0 * NP_PER_DB
        f_alpha = material.atten_freq_hz
    return Layer(material.name, material.z_specific, material.velocity, thickness,
                 alpha0, f_alpha, alpha_exp)


def wavenumber(layer: Layer, f: ArrayLike) -> np.ndarray:
    """Complex wavenumber k_c = w/v - j alpha(f)  (Eq. 4.3)."""
    f = np.asarray(f, dtype=float)
    alpha = layer.alpha0 * (f / layer.f_alpha) ** layer.alpha_exp if layer.alpha0 else 0.0
    return 2 * math.pi * f / layer.velocity - 1j * alpha


def characteristic_impedance(layer: Layer, f: ArrayLike, area: float) -> np.ndarray:
    """Mechanical characteristic impedance Z = rho w A / k_c  (Eq. 4.4).

    Reduces to rho v A when the layer is lossless; keeps a lossy layer passive.
    """
    f = np.asarray(f, dtype=float)
    if layer.alpha0 == 0.0:
        return np.full(f.shape, layer.z_specific * area, dtype=complex)
    k = wavenumber(layer, f)
    return layer.density * 2 * math.pi * f * area / k


def abcd_layer(layer: Layer, f: ArrayLike, area: float):
    """Transfer-matrix entries (A, B, C, D) of Eq. 4.1 as arrays over ``f``."""
    k = wavenumber(layer, f)
    z = characteristic_impedance(layer, f, area)
    kd = k * layer.thickness
    c, s = np.cos(kd), np.sin(kd)
    return c, 1j * z * s, 1j * s / z, c


def input_impedance(layer: Layer, f: ArrayLike, area: float, z_load: ArrayLike) -> np.ndarray:
    """Input impedance of one layer terminated by ``z_load`` (Eq. 4.2), via the ABCD form.

    The ABCD form (A Z + B)/(C Z + D) avoids the tan() poles of Eq. 4.2.
    """
    a, b, c, d = abcd_layer(layer, f, area)
    z_load = np.asarray(z_load, dtype=complex)
    return (a * z_load + b) / (c * z_load + d)


def stack_input_impedance(layers: tuple[Layer, ...] | list[Layer], f: ArrayLike, area: float,
                          z_terminal: ArrayLike) -> np.ndarray:
    """Impedance looking into ``layers[0]`` when the last layer is terminated by ``z_terminal``.

    ``layers`` are ordered from the observer outwards.
    """
    z = np.broadcast_to(np.asarray(z_terminal, dtype=complex), np.shape(np.asarray(f))).copy()
    for layer in reversed(list(layers)):
        z = input_impedance(layer, f, area, z)
    return z
