"""Export helpers used by the application: CSV tables, design JSON, PNG figures and a PDF report.

The PDF is produced with matplotlib's PdfPages so that no extra rendering engine is needed.
"""

from __future__ import annotations

import io
import json
import math
import textwrap
from datetime import date

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.backends.backend_pdf import PdfPages  # noqa: E402

from ustx.models import Response, TransducerDesign  # noqa: E402
from ustx.performance import Metrics, impulse_response  # noqa: E402
from ustx.visualisation import apply_style  # noqa: E402

DISCLAIMER = (
    "One-dimensional KLM simulation. Not validated against measurement. Insertion loss excludes "
    "diffraction, tissue attenuation and reflector loss."
)


def response_table(r: Response) -> pd.DataFrame:
    with np.errstate(divide="ignore"):
        return pd.DataFrame(
            {
                "f_Hz": r.f,
                "Zin_real_ohm": r.zin.real,
                "Zin_imag_ohm": r.zin.imag,
                "Zin_abs_ohm": np.abs(r.zin),
                "Zin_phase_deg": np.degrees(np.angle(r.zin)),
                "H_tx_abs_Pa_per_V": np.abs(r.h_tx),
                "H_rx_abs_V_per_Pa": np.abs(r.h_rx),
                "H_pe_abs": np.abs(r.h_pe),
                "H_pe_dB": 20 * np.log10(np.abs(r.h_pe)),
                "G_tx": r.g_tx,
                "efficiency": r.efficiency,
                "IL2_dB": r.insertion_loss_db(),
            }
        )


def metrics_table(m: Metrics) -> pd.DataFrame:
    return pd.DataFrame([{"metric": k, "value": v} for k, v in m.as_dict().items()])


def design_json(d: TransducerDesign) -> str:
    info = d.describe()
    info["piezo_constants"] = {
        "density": d.piezo.density,
        "c33D_Pa": d.piezo.c33d,
        "eps33S_rel": d.piezo.eps33s_rel,
        "kt": d.piezo.kt,
        "Qm": None if math.isinf(d.piezo.qm) else d.piezo.qm,
        "tan_delta": d.piezo.tan_delta_e,
        "flags": list(d.piezo.flags),
    }
    info["front_layers_detail"] = [
        {
            "name": L.name,
            "z_Rayl": L.z_specific,
            "velocity_m_s": L.velocity,
            "thickness_m": L.thickness,
            "alpha0_Np_m": L.alpha0,
            "f_alpha_Hz": L.f_alpha,
        }
        for L in d.front_layers
    ]
    return json.dumps(info, indent=2)


def figure_set(r: Response, title: str = "") -> dict[str, plt.Figure]:
    """Impedance, frequency response and pulse figures for one response."""
    apply_style()
    f = r.f / 1e6
    figs = {}
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(7, 5), sharex=True)
    a1.semilogy(f, np.abs(r.zin))
    a2.plot(f, np.degrees(np.angle(r.zin)))
    a1.set_ylabel("|Z_in| (ohm)")
    a2.set_ylabel("Phase (deg)")
    a2.set_xlabel("Frequency (MHz)")
    a1.set_title(f"Electrical input impedance {title}")
    figs["impedance"] = fig
    fig, ax = plt.subplots(figsize=(7, 4))
    for q, lab in (("h_pe", "pulse-echo"), ("h_tx", "transmit"), ("h_rx", "receive")):
        y = np.abs(getattr(r, q))
        ax.plot(f, 20 * np.log10(np.maximum(y / y.max(), 1e-9)), label=lab)
    ax.set_ylim(-40, 3)
    ax.axhline(-6, color="grey", ls="--", lw=0.8)
    ax.set_xlabel("Frequency (MHz)")
    ax.set_ylabel("Magnitude (dB re own peak)")
    ax.legend()
    ax.set_title(f"Frequency response {title}")
    figs["response"] = fig
    t, s = impulse_response(r.f, r.h_pe)
    fig, ax = plt.subplots(figsize=(7, 3.5))
    ax.plot(t * 1e6, s / np.abs(s).max())
    ax.set_xlim(-1, 3)
    ax.set_xlabel("Time relative to envelope peak (us)")
    ax.set_ylabel("Normalised voltage")
    ax.set_title(f"Pulse-echo impulse response {title}")
    figs["pulse"] = fig
    return figs


def png_bytes(fig: plt.Figure) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
    return buf.getvalue()


def pdf_report(
    design: TransducerDesign, metrics: Metrics, response: Response, extra_tables: dict | None = None
) -> bytes:
    """Multi-page PDF: summary text, metric table, figures."""
    buf = io.BytesIO()
    with PdfPages(buf) as pdf:
        fig = plt.figure(figsize=(8.27, 11.69))
        lines = [
            f"Transducer simulation report ({date.today().isoformat()})",
            "",
            *textwrap.wrap(DISCLAIMER, 95),
            "",
            "Design:",
        ]
        lines += [f"  {k}: {v}" for k, v in design.describe().items()]
        lines += ["", "Metrics:"]
        lines += [f"  {k}: {v:.4g}" if isinstance(v, float) else f"  {k}: {v}" for k, v in metrics.as_dict().items()]
        if design.piezo.flags:
            lines += ["", "Material flags:"] + [f"  {fl}" for fl in design.piezo.flags]
        for i, line in enumerate(lines):
            fig.text(0.06, 0.96 - i * 0.0175, line, family="monospace", fontsize=7.5)
        pdf.savefig(fig)
        plt.close(fig)
        for f in figure_set(response).values():
            pdf.savefig(f, bbox_inches="tight")
            plt.close(f)
        for name, df in (extra_tables or {}).items():
            fig = plt.figure(figsize=(8.27, 11.69))
            fig.text(0.06, 0.96, name, fontsize=11)
            txt = df.head(60).to_string(max_colwidth=40)
            fig.text(0.04, 0.93, txt, family="monospace", fontsize=6, va="top")
            pdf.savefig(fig)
            plt.close(fig)
    return buf.getvalue()
