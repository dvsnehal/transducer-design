"""Matplotlib figure helpers (static figures for the report and slides).

Conventions: frequency in MHz, time in microseconds, magnitudes in dB relative to a stated
reference; every axis carries units; colours come from one categorical palette that remains
distinguishable for common colour-vision deficiencies (Okabe-Ito).
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

from ustx.models import Response  # noqa: E402
from ustx.performance import impulse_response  # noqa: E402

PALETTE = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9", "#000000", "#F0E442"]


def apply_style() -> None:
    plt.rcParams.update({
        "figure.dpi": 110, "savefig.dpi": 200, "font.size": 10, "axes.titlesize": 11,
        "axes.labelsize": 10, "legend.fontsize": 8, "axes.grid": True, "grid.alpha": 0.3,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.prop_cycle": matplotlib.cycler(color=PALETTE),
    })


def save(fig, path: str | Path) -> str:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def plot_impedance(responses: dict[str, np.ndarray], f: np.ndarray, title: str = ""):
    """|Z_in| and phase for several labelled impedance arrays on a shared frequency grid."""
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(7, 5.5), sharex=True)
    for label, z in responses.items():
        a1.semilogy(f / 1e6, np.abs(z), label=label)
        a2.plot(f / 1e6, np.degrees(np.angle(z)), label=label)
    a1.set_ylabel("|Z_in| (ohm)")
    a2.set_ylabel("Phase (degrees)")
    a2.set_xlabel("Frequency (MHz)")
    a1.legend()
    if title:
        a1.set_title(title)
    return fig


def plot_response(responses: dict[str, Response], quantity: str = "h_pe", normalise: bool = True,
                  title: str = "", f_max_mhz: float | None = None, ylim_db: float = -40):
    """Magnitude in dB of a transfer function for several labelled responses."""
    fig, ax = plt.subplots(figsize=(7, 4))
    for label, r in responses.items():
        y = np.abs(getattr(r, quantity))
        ref = y.max() if normalise else 1.0
        ax.plot(r.f / 1e6, 20 * np.log10(np.maximum(y / ref, 1e-12)), label=label)
    ax.axhline(-6 if quantity == "h_pe" else -3, color="grey", lw=0.8, ls="--")
    ax.set_xlabel("Frequency (MHz)")
    ylabel = {"h_pe": "Pulse-echo |H_pe|", "h_tx": "Transmit |H_tx|", "h_rx": "Receive |H_rx|"}[quantity]
    ax.set_ylabel(f"{ylabel} (dB{' re peak' if normalise else ''})")
    ax.set_ylim(ylim_db, 3 if normalise else None)
    if f_max_mhz:
        ax.set_xlim(0, f_max_mhz)
    ax.legend()
    if title:
        ax.set_title(title)
    return fig


def plot_pulse(responses: dict[str, Response], title: str = "", window_us: float = 2.0):
    """Normalised pulse-echo impulse responses (time origin at the envelope peak)."""
    fig, ax = plt.subplots(figsize=(7, 4))
    for i, (label, r) in enumerate(responses.items()):
        t, s = impulse_response(r.f, r.h_pe)
        s = s / np.abs(s).max()
        ax.plot(t * 1e6, s - 2.2 * i, label=label)
    ax.set_xlim(-window_us / 2, window_us)
    ax.set_xlabel("Time relative to envelope peak (us)")
    ax.set_ylabel("Normalised pulse-echo voltage (offset per trace)")
    ax.set_yticks([])
    ax.legend(loc="upper right")
    if title:
        ax.set_title(title)
    return fig


def plot_pareto_projections(fronts: dict[str, np.ndarray], highlight: dict[str, np.ndarray] | None = None,
                            title: str = ""):
    """Three 2-D projections of 3-objective fronts given as F = (-FBW, IL, tau_us)."""
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    pairs = [((0, 1), "-6 dB FBW (%)", "Two-way insertion loss (dB)"),
             ((0, 2), "-6 dB FBW (%)", "Pulse length tau_-20 (us)"),
             ((1, 2), "Two-way insertion loss (dB)", "Pulse length tau_-20 (us)")]
    for ax, ((i, j), xl, yl) in zip(axes, pairs):
        for label, F in fronts.items():
            x = -F[:, i] if i == 0 else F[:, i]
            y = F[:, j]
            ax.scatter(x, y, s=12, alpha=0.75, label=label)
        for label, F in (highlight or {}).items():
            F = np.atleast_2d(F)
            x = -F[:, i] if i == 0 else F[:, i]
            ax.scatter(x, F[:, j], s=120, marker="*", edgecolor="k", zorder=5, label=label)
        ax.set_xlabel(xl)
        ax.set_ylabel(yl)
    axes[0].legend()
    if title:
        fig.suptitle(title)
    return fig
