"""Traceable material database.

The CSV ``data/material_properties.csv`` stores *only* values that appear in a cited source, plus
explicit ``missing`` and ``approximation`` rows. Everything the model needs but the source does
not give is derived here by a named rule, and every derivation is recorded so that it can be
shown to the user (``MaterialDatabase.derivations``).

Derivation rules
----------------
R1  v = sqrt(c33D / rho)                                  (framework Eq. 2.1)
R2  eps33S = eps33T (1 - kp^2)(1 - kt^2)                  (Berlincourt identity for 6mm ceramics;
                                                           checked against TP-226 in the tests)
R3  eps33S ~= eps33T (1 - kt^2) when kp is not reported   (approximation, flagged)
R4  v = 2 Nt / (fs/fp)(kt), Nt defined at series resonance (inverse of framework Eq. 2.12)
R5  c33D = rho v^2 when only a velocity is reported
R6  Qm missing -> mechanically lossless (upper bound, flagged)
R7  passive attenuation missing -> lossless (flagged; see ASSUMPTIONS A11)
"""

from __future__ import annotations

import csv
import logging
import math
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

from scipy.optimize import brentq

LOG = logging.getLogger(__name__)

DEFAULT_CSV = Path(__file__).resolve().parents[3] / "data" / "material_properties.csv"
DEFAULT_SOURCES = Path(__file__).resolve().parents[3] / "data" / "references" / "material_sources.csv"

REQUIRED_COLUMNS = (
    "material_id", "material_name", "category", "property", "value", "unit", "source_id",
    "source_location", "source_date", "conditions", "uncertainty_rel", "uncertainty_basis",
    "confidence", "status", "notes",
)
CATEGORIES = {"piezo", "matching", "backing", "load", "validation"}
STATUSES = {"reported", "missing", "approximation"}
CONFIDENCE = {"high", "medium", "low", ""}

# property -> (expected unit, lower bound, upper bound) used for validation
PROPERTY_RULES: dict[str, tuple[str, float, float]] = {
    "density": ("kg/m^3", 500.0, 25000.0),
    "c33D": ("Pa", 1e9, 5e11),
    "eps33T_rel": ("-", 1.0, 10000.0),
    "eps33S_rel": ("-", 1.0, 10000.0),
    "eps_rel_unspecified": ("-", 1.0, 10000.0),
    "kt": ("-", 0.0, 1.0),
    "kp": ("-", 0.0, 1.0),
    "k33": ("-", 0.0, 1.0),
    "Qm": ("-", 1.0, 1e5),
    "tan_delta_e": ("-", 0.0, 0.5),
    "Nt": ("Hz*m", 500.0, 5000.0),
    "velocity_thickness": ("m/s", 300.0, 12000.0),
    "velocity_long": ("m/s", 300.0, 12000.0),
    "z_long": ("Rayl", 0.0, 1.2e8),
    "atten_db_per_cm": ("dB/cm", 0.0, 500.0),
}

NP_PER_DB = math.log(10.0) / 20.0


class MaterialDataError(ValueError):
    """Raised when the database violates its schema or physical bounds."""


@dataclass(frozen=True)
class DerivationRecord:
    """One derived or approximated quantity, kept for transparency."""

    material_id: str
    quantity: str
    value: float
    rule: str
    status: str  # "derived" or "approximation"
    note: str = ""


@dataclass(frozen=True)
class PiezoMaterial:
    """Thickness-mode constants of a piezoelectric material (SI units)."""

    material_id: str
    name: str
    density: float
    c33d: float
    eps33s_rel: float
    kt: float
    qm: float  # math.inf means lossless
    tan_delta_e: float
    eps33t_rel: float | None = None
    nt_reported: float | None = None
    uncertainty: dict[str, float] = field(default_factory=dict, compare=False, hash=False)
    flags: tuple[str, ...] = ()

    @property
    def velocity(self) -> float:
        """Real part of the stiffened longitudinal velocity, m/s (rule R1)."""
        return math.sqrt(self.c33d / self.density)

    @property
    def z_specific(self) -> float:
        """Specific acoustic impedance rho*v, Rayl."""
        return self.density * self.velocity

    def with_overrides(self, **changes: float) -> PiezoMaterial:
        """Return a copy with selected constants replaced (used by robustness studies)."""
        data = {k: getattr(self, k) for k in (
            "material_id", "name", "density", "c33d", "eps33s_rel", "kt", "qm", "tan_delta_e",
            "eps33t_rel", "nt_reported")}
        data.update(changes)
        return PiezoMaterial(**data, uncertainty=self.uncertainty, flags=self.flags)


@dataclass(frozen=True)
class PassiveMaterial:
    """Isotropic passive material for matching layers, backings and loads (SI units)."""

    material_id: str
    name: str
    role: str
    density: float | None
    velocity: float | None
    z_specific: float
    atten_db_per_cm: float | None = None
    atten_freq_hz: float | None = None
    uncertainty: dict[str, float] = field(default_factory=dict, compare=False, hash=False)
    flags: tuple[str, ...] = ()

    def alpha_np_per_m(self, frequency_hz: float, exponent: float = 1.0) -> float:
        """Attenuation at ``frequency_hz`` in Np/m, scaled as (f/f0)^exponent (ASSUMPTIONS A8)."""
        if not self.atten_db_per_cm or not self.atten_freq_hz:
            return 0.0
        alpha0 = self.atten_db_per_cm * 100.0 * NP_PER_DB
        return alpha0 * (frequency_hz / self.atten_freq_hz) ** exponent


def series_parallel_ratio(kt: float) -> float:
    """Return fs/fp of a lossless free plate for coupling ``kt`` (framework Eq. 2.12).

    Solves tan(x)/x = 1/kt^2 with x = (pi/2) fs/fp on (0, pi/2).
    """
    if not 0.0 < kt < 1.0:
        raise ValueError(f"kt must lie in (0, 1); got {kt}")
    target = 1.0 / kt**2
    x = brentq(lambda y: math.tan(y) / y - target, 1e-9, math.pi / 2 - 1e-12, xtol=1e-15)
    return x / (math.pi / 2)


def kt_from_resonances(fs: float, fp: float) -> float:
    """IEEE Std 176 relation: kt^2 = (pi/2)(fs/fp) tan[(pi/2)(fp - fs)/fp]  (Eq. 2.12)."""
    if not 0 < fs < fp:
        raise ValueError("require 0 < fs < fp")
    r = fs / fp
    return math.sqrt((math.pi / 2) * r * math.tan((math.pi / 2) * (1 - r)))


@dataclass
class _Row:
    material_id: str
    material_name: str
    category: str
    prop: str
    value: float | None
    unit: str
    source_id: str
    status: str
    confidence: str
    uncertainty_rel: float | None
    raw: dict[str, str]


class MaterialDatabase:
    """In-memory view of the CSV with derived, model-ready material objects."""

    def __init__(self, rows: list[_Row], sources: dict[str, dict[str, str]]):
        self.rows = rows
        self.sources = sources
        self.derivations: list[DerivationRecord] = []
        self.excluded: dict[str, str] = {}
        self.piezo: dict[str, PiezoMaterial] = {}
        self.passive: dict[str, PassiveMaterial] = {}
        self._build()

    # ------------------------------------------------------------------ helpers
    def _props(self, material_id: str) -> dict[str, _Row]:
        return {r.prop: r for r in self.rows if r.material_id == material_id}

    @staticmethod
    def _val(props: dict[str, _Row], name: str) -> float | None:
        row = props.get(name)
        return None if row is None or row.status == "missing" else row.value

    def _record(self, mid: str, qty: str, value: float, rule: str, status: str, note: str = "") -> None:
        self.derivations.append(DerivationRecord(mid, qty, value, rule, status, note))

    # ------------------------------------------------------------------ build
    def _build(self) -> None:
        ids: dict[str, tuple[str, str]] = {}
        for r in self.rows:
            ids.setdefault(r.material_id, (r.material_name, r.category))
        for mid, (name, cat) in ids.items():
            props = self._props(mid)
            try:
                if cat == "piezo":
                    self.piezo[mid] = self._build_piezo(mid, name, props)
                elif cat in {"matching", "backing", "load"}:
                    self.passive[mid] = self._build_passive(mid, name, cat, props)
            except _Incomplete as exc:
                self.excluded[mid] = str(exc)
                LOG.info("material %s excluded from simulation: %s", mid, exc)

    def _build_piezo(self, mid: str, name: str, p: dict[str, _Row]) -> PiezoMaterial:
        flags: list[str] = []
        rho = self._val(p, "density")
        kt = self._val(p, "kt")
        if rho is None or kt is None:
            raise _Incomplete("density or kt not reported")
        c33d = self._val(p, "c33D")
        nt = self._val(p, "Nt")
        if c33d is None:
            v_rep = self._val(p, "velocity_thickness")
            if v_rep is not None:
                c33d = rho * v_rep**2
                self._record(mid, "c33D", c33d, "R5 c33D = rho v^2", "derived")
            elif nt is not None:
                v = 2.0 * nt / series_parallel_ratio(kt)
                c33d = rho * v**2
                self._record(mid, "velocity", v, "R4 v = 2 Nt / (fs/fp)(kt)", "derived")
                flags.append("velocity derived from Nt and kt")
            else:
                raise _Incomplete("no stiffness, velocity or frequency constant")
        eps_s = self._val(p, "eps33S_rel")
        eps_t = self._val(p, "eps33T_rel")
        kp = self._val(p, "kp")
        if eps_s is None:
            if eps_t is None:
                raise _Incomplete("no permittivity")
            if kp is not None:
                eps_s = eps_t * (1 - kp**2) * (1 - kt**2)
                self._record(mid, "eps33S_rel", eps_s, "R2 eps33T(1-kp^2)(1-kt^2)", "derived")
            else:
                eps_s = eps_t * (1 - kt**2)
                self._record(mid, "eps33S_rel", eps_s, "R3 eps33T(1-kt^2)", "approximation",
                             "kp not reported")
                flags.append("eps33S approximated without kp")
        qm = self._val(p, "Qm")
        if qm is None:
            qm = math.inf
            self._record(mid, "Qm", qm, "R6 lossless", "approximation",
                         "mechanical Q not reported; results are an upper bound")
            flags.append("mechanically lossless (Qm missing): optimistic upper bound")
        tan_d = self._val(p, "tan_delta_e") or 0.0
        unc = {r.prop: r.uncertainty_rel for r in p.values() if r.uncertainty_rel is not None}
        return PiezoMaterial(mid, name, rho, c33d, eps_s, kt, qm, tan_d, eps_t, nt, unc, tuple(flags))

    def _build_passive(self, mid: str, name: str, role: str, p: dict[str, _Row]) -> PassiveMaterial:
        flags: list[str] = []
        rho = self._val(p, "density")
        v = self._val(p, "velocity_long")
        z = self._val(p, "z_long")
        if z is None:
            if rho is None or v is None:
                raise _Incomplete("no impedance")
            z = rho * v
            self._record(mid, "z_long", z, "z = rho v", "derived")
        elif rho is not None and v is not None and z > 0:
            mismatch = abs(rho * v / z - 1)
            if mismatch > 0.03:
                LOG.warning("%s: rho*v differs from reported Z by %.1f %%", mid, 100 * mismatch)
                flags.append(f"rho*v and Z disagree by {100 * mismatch:.1f} %")
        att = self._val(p, "atten_db_per_cm")
        att_f = None
        if att is not None:
            att_f = _parse_freq(p["atten_db_per_cm"].raw.get("conditions", ""))
        elif role in {"matching", "backing"} and z > 0:
            self._record(mid, "attenuation", 0.0, "R7 lossless", "approximation",
                         "attenuation not reported")
            flags.append("attenuation not reported: modelled as lossless")
        unc = {r.prop: r.uncertainty_rel for r in p.values() if r.uncertainty_rel is not None}
        return PassiveMaterial(mid, name, role, rho, v, z, att, att_f, unc, tuple(flags))

    # ------------------------------------------------------------------ queries
    def by_role(self, role: str) -> list[PassiveMaterial]:
        """Passive materials with the given role, sorted by impedance."""
        return sorted((m for m in self.passive.values() if m.role == role), key=lambda m: m.z_specific)

    def table(self):
        """Return the raw rows as a pandas DataFrame (import kept local for speed)."""
        import pandas as pd

        return pd.DataFrame([r.raw for r in self.rows])

    def missing_report(self):
        """Rows whose status is 'missing' or 'approximation', plus derivations."""
        import pandas as pd

        rows = [r.raw for r in self.rows if r.status in {"missing", "approximation"}]
        der = pd.DataFrame([d.__dict__ for d in self.derivations])
        return pd.DataFrame(rows), der


class _Incomplete(Exception):
    pass


def _parse_freq(conditions: str) -> float | None:
    """Parse '2 MHz' style conditions into Hz."""
    tokens = conditions.replace("MHz", " MHz").split()
    for i, tok in enumerate(tokens[:-1]):
        if tokens[i + 1] == "MHz":
            try:
                return float(tok) * 1e6
            except ValueError:
                continue
    return None


def _to_float(text: str) -> float | None:
    text = (text or "").strip()
    return None if text == "" else float(text)


def _validate(rows: list[_Row], sources: dict[str, dict[str, str]]) -> None:
    errors: list[str] = []
    seen: set[tuple[str, str]] = set()
    for r in rows:
        key = (r.material_id, r.prop)
        if key in seen:
            errors.append(f"duplicate property {key}")
        seen.add(key)
        if r.category not in CATEGORIES:
            errors.append(f"{key}: unknown category {r.category}")
        if r.status not in STATUSES:
            errors.append(f"{key}: unknown status {r.status}")
        if r.confidence not in CONFIDENCE:
            errors.append(f"{key}: unknown confidence {r.confidence}")
        if r.source_id not in sources:
            errors.append(f"{key}: source {r.source_id} not in source register")
        if r.status == "missing":
            if r.value is not None:
                errors.append(f"{key}: missing rows must have an empty value")
            continue
        if r.value is None:
            errors.append(f"{key}: value is empty but status is {r.status}")
            continue
        rule = PROPERTY_RULES.get(r.prop)
        if rule is None:
            errors.append(f"{key}: unknown property")
            continue
        unit, lo, hi = rule
        if r.unit != unit:
            errors.append(f"{key}: unit '{r.unit}' expected '{unit}'")
        if not lo <= r.value <= hi:
            errors.append(f"{key}: value {r.value} outside [{lo}, {hi}]")
        if r.uncertainty_rel is not None and not 0 <= r.uncertainty_rel < 1:
            errors.append(f"{key}: uncertainty_rel must be in [0, 1)")
    if errors:
        raise MaterialDataError("material database invalid:\n  " + "\n  ".join(errors))


def read_rows(csv_path: Path) -> list[_Row]:
    """Read and type the CSV rows (no validation)."""
    with open(csv_path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        missing = set(REQUIRED_COLUMNS) - set(reader.fieldnames or [])
        if missing:
            raise MaterialDataError(f"missing columns: {sorted(missing)}")
        rows = []
        for raw in reader:
            rows.append(_Row(
                material_id=raw["material_id"].strip(),
                material_name=raw["material_name"].strip(),
                category=raw["category"].strip(),
                prop=raw["property"].strip(),
                value=_to_float(raw["value"]),
                unit=raw["unit"].strip(),
                source_id=raw["source_id"].strip(),
                status=raw["status"].strip(),
                confidence=raw["confidence"].strip(),
                uncertainty_rel=_to_float(raw["uncertainty_rel"]),
                raw=raw,
            ))
    return rows


def read_sources(path: Path) -> dict[str, dict[str, str]]:
    with open(path, newline="", encoding="utf-8") as fh:
        return {row["source_id"]: row for row in csv.DictReader(fh)}


def load_database(csv_path: str | Path | None = None,
                  sources_path: str | Path | None = None) -> MaterialDatabase:
    """Load, validate and derive. Raises ``MaterialDataError`` on any schema violation."""
    csv_path = Path(csv_path) if csv_path else DEFAULT_CSV
    sources_path = Path(sources_path) if sources_path else DEFAULT_SOURCES
    rows = read_rows(csv_path)
    sources = read_sources(sources_path)
    _validate(rows, sources)
    return MaterialDatabase(rows, sources)


@lru_cache(maxsize=1)
def default_database() -> MaterialDatabase:
    """Cached default database (read-only use)."""
    return load_database()
